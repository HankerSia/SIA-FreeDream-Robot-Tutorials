^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package barrett_hand
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2015-07-29)
------------------
* barrett_hand: removing dependency on bhand_description
* Preparing changelog
* Adding changelog files
* Updating package.xml files
* Updating packages.xml config files
* Adding initial structure
* Contributors: RobotnikRoman, RomanRobotnik
