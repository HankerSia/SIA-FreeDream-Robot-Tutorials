^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package bhand_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2015-07-29)
------------------
* bhand_controller: renaming README
* Preparing changelog
* Modifying .gitignore, CMakelist to install the packages, removing .pyc files
* Modifying .gitignore, CMakelist to install the packages, removing .pyc files
* Indigo supported packages
* Adding changelog files
* Adding changelog files
* Updating package.xml files
* Updating packages.xml config files
* Adding initial structure
* Contributors: Elena Gambaro, RobotnikRoman, RomanRobotnik
