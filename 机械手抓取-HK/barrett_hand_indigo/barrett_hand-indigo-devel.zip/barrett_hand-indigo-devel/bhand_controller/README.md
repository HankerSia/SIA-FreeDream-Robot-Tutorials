EXTERNAL DEPENDENCIES
---------------------


