^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cob_extern
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.4 (2016-04-01)
------------------

0.6.3 (2015-08-31)
------------------

0.6.2 (2015-08-25)
------------------
* migrate to package format v2
* Contributors: ipa-mig

0.6.1 (2015-05-28)
------------------

0.6.0 (2014-09-16)
------------------

0.5.3 (2014-08-25)
------------------
* Update package.xml
* New maintainer
* Contributors: Florian Weisshardt, ipa-nhg

0.5.2 (2014-03-20)
------------------
* Merge branch 'hydro_dev' into hydro_release_candidate
* Update package.xml
* Contributors: Florian Weißhardt, ipa-fmw

0.5.1 (2014-03-19)
------------------
* add changelogs
* Update package.xml
* Catkinized version of stack.
  Needs checking of build flags in cob_drivers.
  Also includes updating of libphidgets to 2.1.8 for newer boards.
* Contributors: Alexander Bubeck, abubeck, ipa-fmw