Travis-CI: [![Build Status](https://travis-ci.org/ipa320/cob_extern.svg?branch=indigo_dev)](https://travis-ci.org/ipa320/cob_extern)

This is a repository for Care-O-bot external and third party packages.

Installation instructions and tutorials can be found at http://www.care-o-bot.org.
