SOURCE_DIR=build/libphidget-2.1.8.20151217
cd $SOURCE_DIR && make install
