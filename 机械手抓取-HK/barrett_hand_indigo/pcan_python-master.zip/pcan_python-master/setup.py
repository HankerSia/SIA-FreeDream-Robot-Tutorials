#!/usr/bin/env python
#from distutils.core import setup
from setuptools import setup

setup(
    name='pcan_python',
    version='0.1dev',
    packages=['pcan_python',],
    license='BSD',
    long_description="This driver is a Python wrapper of the  peak-linux-driver (in C) for Linux.",
    )
