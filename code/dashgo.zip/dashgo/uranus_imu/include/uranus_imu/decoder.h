#ifndef DECODER_H
#define DECODER_H

//communication status
enum status{
    kStatus_Idle,
    kStatus_Cmd,
    kStatus_LenLow,
    kStatus_LenHigh,
    kStatus_CRCLow,
    kStatus_CRCHigh,
    kStatus_Data,
};

//data type
enum ItemID{
    kItemID = 0x90,   /* user programed ID    size: 1 */
    kItemAccRaw = 0xA0,   /* raw acc              size: 3x2 */
    kItemGyoRaw = 0xB0,   /* raw gyro             size: 3x2 */
    kItemMagRaw = 0xC0,   /* raw mag              size: 3x2 */
    kItemAtdE = 0xD0,   /* eular angle          size:3x2 */
    kItemPressure = 0xF0,   /* pressure             size:1x4 */
    kItemEnd = 0xFF,
};

class Decoder
{
public:
    Decoder()
    {
         receive_state_ = kStatus_Idle;//初始为空闲状态，等待接收数据
         MAX_PACKET_LEN = 128;         //数据包的最大长度为128
	 	 DataCounter = 0;
    }
    unsigned char byteAnalysisCall(const unsigned char rx_byte);

private:
    unsigned char receiveFiniteStates(const unsigned char rx_data);
    unsigned char packageAnalysis(void);
    unsigned short crc16(unsigned short crc, unsigned char* data, int start, int length, unsigned short poly);
    
    //used for communication
    short   MAX_PACKET_LEN;  //一个数据包的最大长度
    short   DataLen;         //数据包长度
    status  receive_state_;  //数据接收状态
    unsigned char    OpCode;          //帧类别，固定为0xA5
    int     DataCounter;     //数据索引
    unsigned char    header[4];       //表头数据
    unsigned char    DataBuf[256];    //存储接收的数据
    short   CRCReceived;
    short   CRCCalculated;

public:
     //imu data
     unsigned char imu_ID;
     short ra[3];
     short rg[3];
     short rm[3];
     float AtdE[3];
     int   Pressure;  
};


#endif  // #ifndef DECODER_H

