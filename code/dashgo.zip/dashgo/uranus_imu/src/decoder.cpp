#include <uranus_imu/decoder.h>
#include "stdio.h"
#include <string.h>

unsigned char Decoder::byteAnalysisCall(const unsigned char rx_byte)
{
    unsigned char package_update=0;
    unsigned char receive_message_update=0;
    
    receive_message_update=receiveFiniteStates(rx_byte) ;  //Jump communication status
    //printf("%02x ",rx_byte);
    if( receive_message_update ==1 )
    {
        receive_message_update = 0;
        package_update=packageAnalysis();
       
        return package_update;
    }
    return 0;
}


unsigned char Decoder::receiveFiniteStates(const unsigned char rx_data)
{
    switch (receive_state_)
    {
    	case kStatus_Idle:
             if (rx_data == 0x5A)
             {
                header[0] = 0x5A;
             	receive_state_ = kStatus_Cmd;
             }
             break;
        case kStatus_Cmd:
             OpCode = rx_data;
             if (OpCode == 0xA5)
             {  
                 header[1] = 0xA5;
                 receive_state_ = kStatus_LenLow;
             }
             else
             {
                 receive_state_ = kStatus_Idle;
             }
             break;
        case kStatus_LenLow:
             DataLen = rx_data;
	     header[2] = rx_data;
             receive_state_ = kStatus_LenHigh;
             break;
        case kStatus_LenHigh:
   	     header[3] = rx_data;
             DataLen += (short)(rx_data << 8);
             if (DataLen > MAX_PACKET_LEN)
             {
                 receive_state_ = kStatus_Idle;
             }
             else
             {
                 receive_state_ = kStatus_CRCLow;
             }
             break;
        case kStatus_CRCLow:
             CRCReceived = rx_data;
             receive_state_ = kStatus_CRCHigh;
             break;
        case kStatus_CRCHigh:
             CRCReceived += (short)(rx_data << 8);
             DataCounter = 0;
             receive_state_ = kStatus_Data;
             break;
        case kStatus_Data:
             DataBuf[DataCounter++] = rx_data;
             if (DataCounter >= DataLen)
             {
                 
                 CRCCalculated = crc16(0, header, 0, 4, 0x1021);
                 CRCCalculated = crc16(CRCCalculated, DataBuf, 0, DataLen, 0x1021);
                 // CRC match, Kboot successfully received a packet
                 if (CRCCalculated == CRCReceived)
                 {
		    	     //printf("get a package\r\n");
		    		 receive_state_ = kStatus_Idle;
		             return 1;
                 }
                 else
                 {
                     //printf("PacketDecoder CRC check failed\r\n");
		     
                 }
		 	     receive_state_ = kStatus_Idle;
             }
             break;
    }
    return 0;
}

unsigned char Decoder::packageAnalysis(void)
{
    int offset = 0;
	int len = DataCounter;
	while (offset < len)
	{
		unsigned char cmd = DataBuf[offset];
		switch (cmd)
		{
			case (unsigned char)kItemID:
				imu_ID = DataBuf[offset + 1];
                //printf("IMU:%d",imu_ID);
				offset += 2;
				break;
			case (unsigned char)kItemAccRaw:
				ra[0] = (short)(DataBuf[offset + 1] + (DataBuf[offset + 2] << 8));
				ra[1] = (short)(DataBuf[offset + 3] + (DataBuf[offset + 4] << 8));
				ra[2] = (short)(DataBuf[offset + 5] + (DataBuf[offset + 6] << 8));
				offset += 7;
				break;
			case (unsigned char)kItemGyoRaw:
				rg[0] = (short)(DataBuf[offset + 1] + (DataBuf[offset + 2] << 8));
				rg[1] = (short)(DataBuf[offset + 3] + (DataBuf[offset + 4] << 8));
				rg[2] = (short)(DataBuf[offset + 5] + (DataBuf[offset + 6] << 8));
				offset += 7;
				break;
			case (unsigned char)kItemMagRaw:
				rm[0] = (short)(DataBuf[offset + 1] + (DataBuf[offset + 2] << 8));
				rm[1] = (short)(DataBuf[offset + 3] + (DataBuf[offset + 4] << 8));
				rm[2] = (short)(DataBuf[offset + 5] + (DataBuf[offset + 6] << 8));
                offset += 7;
                break;
   			case (unsigned char)kItemAtdE:
				AtdE[0] = (float)(short)(DataBuf[offset + 1] + (DataBuf[offset + 2] << 8)) / 100;
				AtdE[1] = (float)(short)(DataBuf[offset + 3] + (DataBuf[offset + 4] << 8)) / 100;
				AtdE[2] = (float)(short)(DataBuf[offset + 5] + (DataBuf[offset + 6] << 8)) / 10;
                //printf("RPY:%x,%x  ",DataBuf[offset + 5],DataBuf[offset + 6]);
                //printf("RPY:%f,%f,%f\r\n",AtdE[0],AtdE[1],AtdE[2]);
				offset += 7;
                break;
			case (unsigned char)kItemPressure:
                Pressure = (int)(DataBuf[offset + 1] + (DataBuf[offset + 2] << 8) + (DataBuf[offset + 3] << 16) + (DataBuf[offset + 4] << 24));
                //offset += 5;
                //break;
				return 1;
			default: 
				return 0;            
		}
	}
    return 0;
}




unsigned short Decoder::crc16(unsigned short crc, unsigned char* data, int start, int length, unsigned short poly)
{
    while (length-- > 0)
    {
        char bt = data[start++];
        for (int i = 0; i < 8; i++)
        {
            bool b1 = (crc & 0x8000U) != 0;
            bool b2 = (bt & 0x80U) != 0;
            if (b1 != b2) crc = (unsigned short)((crc << 1) ^ poly);
            else crc <<= 1;
            bt <<= 1;
        }
    }
    return crc;
}











