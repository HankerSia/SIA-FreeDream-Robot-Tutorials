#include <uranus_imu/uranus_ros.h>


namespace uranus_imu {

//节点句柄，串口文件路径，配置文件路径
Uranus_ros::Uranus_ros(ros::NodeHandle &nh, std::string url) :
    uranus_(url),
    nh_(nh)
{

	roll = pitch = yaw =  0.0;
    base_yaw = 0.0;
    current_yaw = last_yaw = 0;
	sum_yaw = 0;
    filter_yaw = 0.0;
    yaw_value_index = 0;
     for (int i=0;i<6;i++)
    {
        yaw_value_buffer[i] = 0.0;      
    }
    if (uranus_.initialize_ok())
    {
        ROS_INFO("system initialized succeed, ready for communication");
    } else
    {
        ROS_ERROR("hf link initialized failed, please check the hardware");
    }    
	

    //获取参数
	controller_freq_ = 30;     //控制频率设为30,需要大于imu传感器的发布频率10Hz
    nh_.getParam("freq", controller_freq_);
	zero_orientation_set = false;
	
	nh.param<std::string>("/uranus_imu_node/tf_parent_frame_id", tf_parent_frame_id, "imu_base");
    nh.param<std::string>("/uranus_imu_node/tf_frame_id", tf_frame_id, "imu");
    nh.param<std::string>("/uranus_imu_node/imu_frame_id", imu_frame_id, "imu_base");
    nh.param<double>("/uranus_imu_node/time_offset_in_seconds", time_offset_in_seconds, 0.0);

	imu_pub = nh.advertise<sensor_msgs::Imu>("imu_data", 1);
  	imu_angle_pub = nh.advertise<std_msgs::Float32>("imu_angle", 1);

    service = nh.advertiseService("set_zero_orientation", &Uranus_ros::set_zero_orientation,this);
}

void Uranus_ros::mainloop()
{
    ros::Rate loop(controller_freq_);

    ros::Time current_time, last_time;
  	current_time = ros::Time::now();
  	last_time = ros::Time::now();
  	ros::Duration dur_time;
    while (ros::ok())
    {
        uranus_.updateIMUData();
        readBufferUpdate();
		
		current_time = ros::Time::now();
        dur_time = current_time - last_time;

        if (!zero_orientation_set)
        {
        	base_yaw = yaw;
        }
        /*删除滑动均值滤波
        char count;
   		float  sum=0.0;
        yaw_value_buffer[yaw_value_index++] = -yaw + base_yaw; 
   		if ( yaw_value_index == 6 )
		      yaw_value_index = 0;
   		for ( count=0;count<6;count++)
      		sum += yaw_value_buffer[count];
   		filter_yaw = sum/6;
        */
        current_yaw = -yaw + base_yaw;
        if ((current_yaw > 90) && (last_yaw < -90))
        {
            sum_yaw = sum_yaw + current_yaw - last_yaw - 360;
        }
        else if ((current_yaw < -90) && (last_yaw > 90))
        {
            sum_yaw = sum_yaw + current_yaw - last_yaw + 360;
        }
        else
        {
            sum_yaw = sum_yaw + current_yaw - last_yaw;
        }
        //filter_yaw = current_yaw + sum_yaw * 0.004; //角度补偿
        filter_yaw = current_yaw + sum_yaw * 0.0029;   //角度补偿，更换雷达后调整

        last_yaw = current_yaw;
        
        //ROS_INFO("yaw:%f filter:%f sum:%f",current_yaw,filter_yaw,sum_yaw);
        //ROS_INFO("filter:%f",filter_yaw);
        //yaw = -yaw + 180;

        if (filter_yaw > 180);
            filter_yaw = filter_yaw - 360;
        if (filter_yaw < -180)
            filter_yaw = filter_yaw + 360;

        tf::Quaternion orientation = tf::createQuaternionFromYaw(filter_yaw*3.14159/180);
        std_msgs::Float32 imu_angle_mgs;
        imu_angle_mgs.data = filter_yaw;
       
        imu_angle_pub.publish(imu_angle_mgs);

        if (!zero_orientation_set)
        {
        	zero_orientation = orientation;
            zero_orientation_set = true;
        }

		tf::Quaternion differential_rotation;   //????
        differential_rotation = zero_orientation.inverse() * orientation;
        // calculate measurement time
        ros::Time measurement_time = ros::Time::now() + ros::Duration(time_offset_in_seconds);
        // publish imu message
        sensor_msgs::Imu imu;
        imu.header.stamp = measurement_time;
        imu.header.frame_id = imu_frame_id;
        quaternionTFToMsg(differential_rotation, imu.orientation);
        // i do not know the orientation covariance
        imu.orientation_covariance[0] = 1000000;
        imu.orientation_covariance[1] = 0;
        imu.orientation_covariance[2] = 0;
        imu.orientation_covariance[3] = 0;
        imu.orientation_covariance[4] = 1000000;
        imu.orientation_covariance[5] = 0;
        imu.orientation_covariance[6] = 0;
        imu.orientation_covariance[7] = 0;
        imu.orientation_covariance[8] = 0.000001;
        // angular velocity is not provided
        imu.angular_velocity_covariance[0] = -1;
              
        //imu.angular_velocity.x = 0.0;
        //imu.angular_velocity.y = 0.0;
        //imu.angular_velocity.z = (double)-1*(angleRate*3.14/(180*100));
        /*
        imu.linear_acceleration.x = (double)(-1*((acc_x+10) * 9.80665/1000.f));
        imu.linear_acceleration.y = (double)(-1*((acc_y+24) * 9.80665/1000.f));
        imu.linear_acceleration.z = (double)(-1*((acc_z-1070) * 9.80665/1000.f));
        */
        imu.linear_acceleration_covariance[0] = -1;
        imu_pub.publish(imu);
        // publish tf transform
        static tf::TransformBroadcaster br;
        tf::Transform transform;
        transform.setRotation(differential_rotation);
        br.sendTransform(tf::StampedTransform(transform, measurement_time, tf_parent_frame_id, tf_frame_id));

    	ros::spinOnce();
        loop.sleep();

    }
}

bool Uranus_ros::set_zero_orientation(std_srvs::Empty::Request&,
                          std_srvs::Empty::Response&)
{
  ROS_INFO("Zero Orientation Set.");
  zero_orientation_set = false;
  return true;
}

}
