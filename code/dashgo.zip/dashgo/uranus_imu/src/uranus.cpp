#include <uranus_imu/uranus.h>

namespace uranus_imu {
//串口路径，配置文件路径
Uranus::Uranus(std::string url)
{
		//串口，hflink配置
    std::string transport_method = url.substr(0, url.find("://"));
    if (transport_method == "serial")
    {
        port_ = boost::make_shared<TransportSerial>(url);
        time_out_ = 500;
	    decoder_ = boost::make_shared<Decoder>();
        timer_.reset(new boost::asio::deadline_timer(*(port_->getIOinstace()),
                                                     boost::posix_time::milliseconds(time_out_)));
    }else if (transport_method == "udp")
    {
    }else if (transport_method == "tcp")
    {
    }

	initialize_ok_ = port_->initialize_ok();
}

void Uranus::timeoutHandler(const boost::system::error_code &ec)
{
    if (!ec)
    {
        std::cerr << "Time Out" <<std::endl;
        boost::mutex::scoped_lock lock(wait_mutex_);
        time_out_flag_ = true;
    }
}


bool Uranus::updateIMUData()
{
    boost::asio::deadline_timer cicle_timer_(*(port_->getIOinstace()));
    cicle_timer_.expires_from_now(boost::posix_time::millisec(time_out_));
    Buffer data = port_->readBuffer();
    ack_ready_ = false;
    while (!ack_ready_)
    {
        for (int i = 0; i < data.size(); i++)
        {
            if (decoder_->byteAnalysisCall(data[i]))
            {
                // one package ack arrived
                ack_ready_ = true;
            }
        }
        data = port_->readBuffer();
        if (cicle_timer_.expires_from_now().is_negative())
        {
            std::cerr<<"Timeout continue skip this package"<<std::endl;
            return false;
        }
    }
    return true;
}
}


