#include <uranus_imu/uranus_ros.h>

int main(int argc, char** argv)
{
    ros::init(argc, argv, "uranus_imu_node");
    ros::NodeHandle nh("urnaus_imu");
	
	std::string port;
	nh.param<std::string>("/uranus_imu_node/port", port, "/dev/ttyUSB0");
	port = "serial://" + port;
    uranus_imu::Uranus_ros imu_device(nh, port);
    imu_device.mainloop();
    return 0;
}
