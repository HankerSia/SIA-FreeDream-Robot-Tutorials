#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <id_data_msgs/ID_Data.h>
#include <math.h>
using namespace std;


nav_msgs::Odometry odom_msg;
id_data_msgs::ID_Data sub_msg;

void infoCallback(const id_data_msgs::ID_Data::ConstPtr& msg)
{
  	sub_msg.id = msg->id;
  	sub_msg.data[0] = msg->data[0];
	if ((msg->id ==2) && (msg->data[0] < 7) && (msg->data[0] > 0))
	{
		sub_msg.data[1] = msg->data[1];
	}
  	
  	//ROS_INFO("msg->data[0]: %d,msg->data[1]: %d",sub_msg.data[0],sub_msg.data[1]);
}


void odomCallback(const nav_msgs::Odometry::ConstPtr& msg )
{
	odom_msg.pose.pose.position.x = msg->pose.pose.position.x;
	odom_msg.pose.pose.position.y = msg->pose.pose.position.y;
}

int main(int argc,char **argv)
{
	
	ros::init(argc,argv,"move_distance_test");
	ros::NodeHandle n;
	

	ros::Publisher  twist_pub = n.advertise<geometry_msgs::Twist>("/cmd_vel",1);
	ros::Subscriber odom_data = n.subscribe("/odom",10,odomCallback);

	ros::Subscriber sub = n.subscribe("/notice", 100, infoCallback);

    geometry_msgs::Twist speed_msgs;
    /*
	int number = 1000;
    speed_msgs.linear.x = 0.10;
	speed_msgs.angular.z = 0.0;
	twist_pub.publish(speed_msgs);
	usleep(number*1000);
	speed_msgs.linear.x = 0.0;
	twist_pub.publish(speed_msgs);
    return 0;
	*/
	double start_position_x;
	double start_position_y;
	double delta_x;
	double delta_y;
	double current_distance = 0.0;
	double target_distance = 0.20;
	bool start_flag = false;
	bool stop_flag = false;
	ros::Rate loop_rate(60);
	int count = 0;
	while(ros::ok())
	{
		while(ros::ok())
		{
			count++;
			if (count >60)
				break;
			ros::spinOnce();
			loop_rate.sleep();
		}
		if (!start_flag)
		{
			start_position_x = odom_msg.pose.pose.position.x;
			start_position_y = odom_msg.pose.pose.position.y;
			start_flag = true;
		}
		if ((sub_msg.id == 1) && (sub_msg.data[0] == 13) )
		{
			ROS_INFO("stop!!!!");
			stop_flag = true;
		}
		if (stop_flag == true)
		{
			speed_msgs.linear.x = 0.0;
			speed_msgs.angular.z = 0.0;
			twist_pub.publish(speed_msgs);
		}
		if (stop_flag == false)
		{
			speed_msgs.angular.z = 0.0;
			delta_x = odom_msg.pose.pose.position.x - start_position_x;
			delta_y = odom_msg.pose.pose.position.y - start_position_y;
			current_distance = sqrt(delta_x*delta_x + delta_y*delta_y);
			ROS_INFO("delta_x:%0.3lf,delta_y:%0.3lf,distance:%0.3lf",delta_x,delta_y,current_distance);
			if ((current_distance*1.28) >= target_distance )
			{
				speed_msgs.linear.x = 0.0;
				twist_pub.publish(speed_msgs);
				break;
			}
			else 
			{
				speed_msgs.linear.x = 0.05;
				twist_pub.publish(speed_msgs);	
			}
		}
		
		ros::spinOnce();
		loop_rate.sleep();
		++count;
	}
}
