#include <ros/ros.h>
#include "sensor_msgs/LaserScan.h"
#include <math.h>
using namespace std;

float angle_min;
float angle_max;
float angle_increment;
float range_min;
float range_max;
//只取+-30度的数据
float ranges[61];
float position_x;
float position_y;

void laser_scanCallback(const sensor_msgs::LaserScan::ConstPtr& msg )
{
	angle_min = msg->angle_min;
    angle_increment = msg->angle_increment;

    for (int i = 0;i< 61;i++)
    {
        if (msg->intensities[i+237] > 1)
        {
			ranges[i] = msg->ranges[i+237];
			//position_x = msg->ranges[i+237] *cos(angle_min+angle_increment*(i+237) - 1.53);
			//position_y = msg->ranges[i+237] *sin(angle_min+angle_increment*(i+237) - 1.53);
           // ROS_INFO("index:%d,x:%0.3f,y:%0.3f",i+237,position_x,position_y);
        }
		else 
		{
			ranges[i] = 0;
		}
    }

}
//获取激光雷达测距信息，
float get_laser_length(int column)
{
	float sum = 0.0;
	float distance;
	int count = 0;
	int value_count = 0;
	ros::Rate loop_rate(30);
	while(ros::ok())
	{
		count++;
		if (count >60)
			break;
		ros::spinOnce();
		loop_rate.sleep();
	}
	while(ros::ok())
	{
		for (int i =0+(column-1)*15;i < 31+(column-1)*15;i++ )
		{	
			if ( ranges[i] >0.05)
			{
				position_x = ranges[i] *cos(angle_min+angle_increment*(i+237) - 1.53);
				//ROS_INFO("data:%0.3f,position_x:%0.3f",ranges[i],position_x);
				value_count++;
				sum += position_x;
			}
			
		}
		if (value_count != 0)
		{
			distance = sum/value_count;
			if (distance > 0.15)
			{	
				ROS_INFO("distance:%0.3f",distance);
				return distance;
			}
			
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	return 0;	
}



int main(int argc,char **argv)
{
	
	ros::init(argc,argv,"LaserScan_test");
	ros::NodeHandle n;
	

	ros::Subscriber laser_scan_data = n.subscribe("/scan",1,laser_scanCallback);
    
	ros::Rate loop_rate(60);
	int count = 0;
	while(ros::ok())
	{
	    count++;
		get_laser_length(1);
		ros::spinOnce();
		loop_rate.sleep();
	}
}


