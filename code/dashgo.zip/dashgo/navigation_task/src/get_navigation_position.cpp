#include <ros/ros.h>

#include <geometry_msgs/PoseStamped.h>


double position_x;
double position_y;
bool first_flag = false;
bool second_flag = false;

/**********************************/
void goalCallback(const geometry_msgs::PoseStamped::ConstPtr &msg)
{

    position_x = msg->pose.position.x;
    position_y = msg->pose.position.y;
    //ROS_INFO("X:%0.3f",msg->pose.position.x);
    //ROS_INFO("X:%0.3f",msg->pose.position.y);
     if (first_flag == true)
    {
         ROS_INFO("Place 1 X: %0.3f, Y: %0.3f",position_x + 0.46,position_y + 0.89);
         second_flag = true;
    }

    if (first_flag == false)
    {
        first_flag = true;
        ROS_INFO("Pick 1 X: %0.3f,Y: %0.3f",position_x - 0.95,position_y - 0.347/2-0.04 -0.02);
        ROS_INFO("Pick 2 X: %0.3f,Y: %0.3f",position_x - 0.95,position_y - 0.347/2-0.08 - 0.347 - 0.02);
        ROS_INFO("Pick 3 X: %0.3f,Y: %0.3f",position_x - 0.95,position_y - 0.347/2-0.12-0.347*2 - 0.02);
    }
   
}

int main(int argc,char **argv)
{
	
   /*读取位置信息*******************************************************************/



	/*********************************************************************************************/

	ros::init(argc,argv,"get_navigation_node");
	ros::NodeHandle n;
	
	//任务通信
	
	ros::Subscriber sub = n.subscribe("/move_base_simple/goal", 10, goalCallback);


	//参数设置，是否使用角度补偿，是否使用调试模式
      
	ros::Rate loop_rate(10);
	int count = 0;
	
	while(ros::ok())
	{
        if (second_flag == true)
            break;
		ros::spinOnce();
		loop_rate.sleep();
		++count;
	}
}
