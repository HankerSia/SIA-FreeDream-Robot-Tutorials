#include <ros/ros.h>
#include "sensor_msgs/LaserScan.h"
#include <math.h>
using namespace std;

float angle_min;
float angle_max;
float angle_increment;
float range_min;
float range_max;
//只取+-30度的数据
float ranges[61];
float ranges_y[20];
float position_x;
float position_y;

void laser_scanCallback(const sensor_msgs::LaserScan::ConstPtr& msg )
{
	angle_min = msg->angle_min;
    angle_increment = msg->angle_increment;

    angle_min = msg->angle_min;
    angle_increment = msg->angle_increment;

    /*for (int i = 0;i< 359;i++)
    {
        if (msg->intensities[i] > 1)
        {
			ranges[i] = msg->ranges[i];
            position_x = ranges[i] *cos(angle_min+angle_increment*(i) - 1.53);
            position_y = ranges[i]*sin(angle_min+angle_increment*(i) - 1.53);
            ROS_INFO("index:%d,data:%0.3f,x:%0.3f,y:%0.3f",i,ranges[i],position_x,position_y);
        }
		else 
		{
			ranges[i] = 0;
		}
    }*/
    for (int i = 0;i< 20;i++)
    {
        if (msg->intensities[i+340] > 1)
        {
			ranges_y[i] = msg->ranges[i+340] * sin(angle_min+angle_increment*(i+340) - 1.53);
            ROS_INFO("index:%d,data:%0.3f,y:%0.3f",i+340,msg->ranges[i+340],ranges_y[i]);
        }
		else 
		{
			ranges_y[i] = 0;
		}
    }

}

float LaserScan_Y_Distance(int column)
{
    int count = 0;
	int value_count = 0;

    float base_distance = 0.717;  //需要标定
    float target_distance;

    float distance;
    float sum = 0;
    if (column == 1)
        target_distance = base_distance;
    if (column == 2)
        target_distance = base_distance + 0.387 ;
    if (column == 3)
        target_distance = base_distance + 0.387*2 ; 

	ros::Rate loop_rate(30);
	while(ros::ok())
	{
		count++;
		if (count >30)
			break;
		ros::spinOnce();
		loop_rate.sleep();
	}
	while(ros::ok())
	{
        value_count = 0;
		for (int i =0;i < 20; i++)
		{	
			if ( (ranges_y[i] > (target_distance - 0.30)) && (ranges_y[i] < (target_distance + 0.30)) )
			{
                sum += ranges_y[i];
                value_count++;
			}	
		}
        distance  = sum / value_count;
		ROS_INFO("Y_Distance:%0.3f", distance);
        if ( (distance > 0.2) && (distance < 2.4) ) 
		{
			ROS_INFO("Y_Distance:%0.3f", distance);
            break;
		}
			
	ros::spinOnce();
	loop_rate.sleep();
	}
	return distance;	
}



int main(int argc,char **argv)
{
	
	ros::init(argc,argv,"LaserScan_Y_Distance");
	ros::NodeHandle n;
	

	ros::Subscriber laser_scan_data = n.subscribe("/scan",1,laser_scanCallback);
    
	ros::Rate loop_rate(60);
	int count = 0;
	while(ros::ok())
	{
	    count++;
        LaserScan_Y_Distance(1);
		ros::spinOnce();
		loop_rate.sleep();
	}
}


