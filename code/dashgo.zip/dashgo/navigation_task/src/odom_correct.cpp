#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <id_data_msgs/ID_Data.h>



bool received_flag = false;
bool correct_flag = false;

nav_msgs::Odometry odom_msg;
id_data_msgs::ID_Data pub_msg;
id_data_msgs::ID_Data sub_msg;

void infoCallback(const id_data_msgs::ID_Data::ConstPtr& msg)
{
  	sub_msg.id = msg->id;
  	sub_msg.data[0] = msg->data[0];
	if ((msg->id ==2) && (msg->data[0] == 9))
	{
        
		sub_msg.data[1] = msg->data[1];
        sub_msg.data[2] = msg->data[2];
        sub_msg.data[3] = msg->data[3];
        correct_flag = true;
	}
  	
  	ROS_INFO("msg->data[0]: %d,msg->data[1]: %d,msg->data[2]: %d,msg->data[3]: %d",
             sub_msg.data[0],sub_msg.data[1],msg->data[2],msg->data[3]);
}

void odomCallback(const nav_msgs::Odometry::ConstPtr& msg )
{
	odom_msg.pose.pose.position.x = msg->pose.pose.position.x;
	odom_msg.pose.pose.position.y = msg->pose.pose.position.y;
    odom_msg.pose.pose.position.z = msg->pose.pose.position.z;
    odom_msg.pose.pose.orientation = msg->pose.pose.orientation;

    odom_msg.twist.twist.linear.x = msg->twist.twist.linear.x;
    odom_msg.twist.twist.linear.y = msg->twist.twist.linear.y;
    odom_msg.twist.twist.angular.z = msg->twist.twist.angular.z;

    for(int i=0;i<36;i=i+7)
    {
        odom_msg.pose.covariance[i]  =  msg->pose.covariance[i];
        odom_msg.twist.covariance[i] =  msg->twist.covariance[i];
    }
    odom_msg.pose.covariance[8]  =  msg->pose.covariance[8];
    odom_msg.twist.covariance[8] =  msg->twist.covariance[8];


    received_flag = true;
    //ROS_INFO("received odom data");
}

int main(int argc, char** argv){
  ros::init(argc, argv, "odometry_correct");

  ros::NodeHandle n;
  ros::Publisher odom_pub = n.advertise<nav_msgs::Odometry>("/odom_correct", 20);
  ros::Subscriber odom_data = n.subscribe("/odom",10,odomCallback);

  ros::Publisher info_pub = n.advertise<id_data_msgs::ID_Data>("/notice",10);
  ros::Subscriber sub = n.subscribe("/notice", 100, infoCallback);

  tf::TransformBroadcaster odom_broadcaster;

  ros::Time current_time;
  geometry_msgs::TransformStamped odom_trans;
  nav_msgs::Odometry odom;
  geometry_msgs::Quaternion odom_quat;

  double correct_x = 0.0;
  double correct_y = 0.0;
  double correct_yaw = 0.0;
  double yaw;


  ros::Rate rate(12);

  //时间戳 注意
  while(n.ok()){

      current_time = ros::Time::now();
      if (received_flag == false)
      {    
            /*
            odom_quat = tf::createQuaternionMsgFromYaw(0.0);
            odom_trans.header.stamp = current_time;
            odom_trans.header.frame_id = "odom_correct";
            odom_trans.child_frame_id = "base_footprint";

            odom_trans.transform.translation.x = 0.0;
            odom_trans.transform.translation.y = 0.0;
            odom_trans.transform.translation.z = 0.0;
            odom_trans.transform.rotation = odom_quat;

            //send the transform
            odom_broadcaster.sendTransform(odom_trans);
      
            odom.header.stamp = current_time;
            odom.header.frame_id = "odom_correct";
            odom.child_frame_id = "base_footprint";

            //set the position
            odom.pose.pose.position.x = 0.0;
            odom.pose.pose.position.y = 0.0;
            odom.pose.pose.position.z = 0.0;
            odom.pose.pose.orientation = odom_quat;

            //set the velocity
            odom.twist.twist.linear.x = 0.0;
            odom.twist.twist.linear.y = 0.0;
            odom.twist.twist.linear.z = 0.0;
            odom.twist.twist.angular.x = 0.0;
            odom.twist.twist.angular.y = 0.0;
            odom.twist.twist.angular.z = 0.0;

            //publish the message
            odom_pub.publish(odom);
            */
      }
      if (received_flag == true)
      {
           // odom_trans.header.stamp = odom_msg.header.stamp;
            odom_trans.header.stamp = current_time;
            odom_trans.header.frame_id = "odom_correct";
            odom_trans.child_frame_id = "base_footprint";

            yaw = tf::getYaw(odom_msg.pose.pose.orientation);
            if (correct_flag == true)
            {
                correct_flag = false;
                //将厘米转换为米
                correct_x = (double)sub_msg.data[1]/100.0 - odom_msg.pose.pose.position.x;
                correct_y = (double)sub_msg.data[2]/100.0 - odom_msg.pose.pose.position.y;
                correct_yaw = (double)sub_msg.data[3]/100.0 - yaw;
            }
            odom_trans.transform.translation.x = odom_msg.pose.pose.position.x + correct_x;
            odom_trans.transform.translation.y = odom_msg.pose.pose.position.y + correct_x;
            odom_trans.transform.translation.z = 0.0;

            yaw = yaw + correct_yaw;
            odom_quat  = tf::createQuaternionMsgFromYaw(yaw);
            odom_trans.transform.rotation = odom_quat;

            //send the transform
            odom_broadcaster.sendTransform(odom_trans);
            
            
            //odom.header.stamp = odom_msg.header.stamp;
            odom.header.stamp = current_time;
            odom.header.frame_id = "odom_correct";
            odom.child_frame_id = "base_footprint";

            //set the position
            odom.pose.pose.position.x = odom_msg.pose.pose.position.x + correct_x;
            odom.pose.pose.position.y = odom_msg.pose.pose.position.y + correct_x;
            odom.pose.pose.position.z = 0.0;
            odom.pose.pose.orientation = odom_quat;

            //set the velocity
            odom.twist.twist.linear.x = odom_msg.twist.twist.linear.x;
            odom.twist.twist.linear.y = odom_msg.twist.twist.linear.y;
            odom.twist.twist.linear.z = odom_msg.twist.twist.linear.z;
            odom.twist.twist.angular.x = odom_msg.twist.twist.angular.x;
            odom.twist.twist.angular.y = odom_msg.twist.twist.angular.y;
            odom.twist.twist.angular.z = odom_msg.twist.twist.angular.z;

           for(int i=0;i<36;i=i+7)
            {
                odom.pose.covariance[i]  =  odom_msg.pose.covariance[i];
                odom.twist.covariance[i] =  odom_msg.twist.covariance[i];
            }
            odom.pose.covariance[8]  =  odom_msg.pose.covariance[8];
            odom.twist.covariance[8] =  odom_msg.twist.covariance[8];

            //publish the message
            odom_pub.publish(odom);
      }
    ros::spinOnce();
    rate.sleep();
  }
}