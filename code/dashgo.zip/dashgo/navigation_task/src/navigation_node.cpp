#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>  
#include <actionlib/client/simple_action_client.h> 
#include <id_data_msgs/ID_Data.h>
#include <fstream>
#include <sstream>

#include <ros/spinner.h>

#include <std_msgs/Float32.h>
#include <geometry_msgs/Twist.h>
#include <std_srvs/Empty.h>
#include "sensor_msgs/LaserScan.h"
#include <nav_msgs/Odometry.h>

#include <math.h>
using namespace std;
typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

MoveBaseClient *acp;  

id_data_msgs::ID_Data pub_msg;
id_data_msgs::ID_Data sub_msg;

std_msgs::Float32 imu_angle_msgs;     //订阅的角度信息
geometry_msgs::Twist speed_msgs;      //发送的速度控制信息
nav_msgs::Odometry odom_msg;          //订阅的里程信息
/**********************************/
//订阅的激光扫描相关数据
float angle_min, angle_max;
float angle_increment;
float range_min, range_max;

//只取+-30度的数据
float ranges[61];   //测试前方角度，距离
float ranges_y[20]; //测试Y方向距离

float position_x, position_y;
/**********************************/
void infoCallback(const id_data_msgs::ID_Data::ConstPtr& msg)
{
  	sub_msg.id = msg->id;
  	sub_msg.data[0] = msg->data[0];
	if ((msg->id ==2) && (msg->data[0] < 7) && (msg->data[0] > 0))
	{
		sub_msg.data[1] = msg->data[1];
	} else if ((msg->id == 5) && (msg->data[0] == 14) ) {
		acp->cancelGoal();
	}	
  	//ROS_INFO("msg->data[0]: %d,msg->data[1]: %d",sub_msg.data[0],sub_msg.data[1]);
}

void imuAngleCallback(const std_msgs::Float32::ConstPtr& msg)
{
	imu_angle_msgs.data = msg->data;
	if ((imu_angle_msgs.data >= -180) && (imu_angle_msgs.data < -135))
	{
		imu_angle_msgs.data += 360;
	}
}
void odomCallback(const nav_msgs::Odometry::ConstPtr& msg )
{
	odom_msg.pose.pose.position.x = msg->pose.pose.position.x;
	odom_msg.pose.pose.position.y = msg->pose.pose.position.y;
	odom_msg.twist.twist.linear.x = msg->twist.twist.linear.x;
}
void laser_scanCallback(const sensor_msgs::LaserScan::ConstPtr& msg )
{
	angle_min = msg->angle_min;
    angle_increment = msg->angle_increment;
	//获取X方向和角度的测距信息
    for (int i = 0;i< 61;i++)
    {
        if (msg->intensities[i+237] > 1)
        {
			ranges[i] = msg->ranges[i+237];
			//position_x = msg->ranges[i+237] *cos(angle_min+angle_increment*(i+237) - 1.53);
			//position_y = msg->ranges[i+237] *sin(angle_min+angle_increment*(i+237) - 1.53);
            //ROS_INFO("index:%d,x:%0.3f,y:%0.3f",i+237,position_x,position_y);
        }
		else 
		{
			ranges[i] = 0;
		}
    }

	//获取Y方向距离的测距信息
	for (int i = 0;i< 20;i++)
    {
        if (msg->intensities[i+340] > 1)
        {
			ranges_y[i] = msg->ranges[i+340] * sin(angle_min+angle_increment*(i+340) - 1.53);
            //ROS_INFO("index:%d,data:%0.3f,y:%0.3f",i+340,msg->ranges[i+340],ranges_y[i]);
        }
		else 
		{
			ranges_y[i] = 0;
		}
    }
}

//获取激光雷达测距信息 Y方向， 距离左侧标志物的距离
float LaserScan_Y_Distance()
{
    int count = 0;
	int value_count = 0;

    float distance;
    float sum = 0;

	ros::Rate loop_rate(30);
	while(ros::ok())
	{
		count++;
		if (count >5)
			break;
		loop_rate.sleep();
	}
	while(ros::ok())
	{
        value_count = 0;
		for (int i =0;i < 20; i++)
		{	
			if ( (ranges_y[i] > 0.20) && (ranges_y[i] < 5.0) )
			{
                sum += ranges_y[i]; 
                value_count++;
			}	
		}
        distance  = sum / value_count;
        if ( (distance > 0.2) && (distance < 5.0) ) 
		{
			ROS_INFO("Y_Distance:%0.3f", distance);
            break;
		}
			
	//
	loop_rate.sleep();
	}
	return distance;	
}
//获取激光雷达测距信息 X方向，距离前方标志物的距离
float get_laser_length(int column)
{
	float sum = 0.0;
	float distance;
	int count = 0;
	int value_count = 0;
	ros::Rate loop_rate(30);
	while(ros::ok())
	{
		count++;
		if (count >5)
			break;
		//
		loop_rate.sleep();
	}
	while(ros::ok())
	{
		for (int i =0+(column-1)*15;i < 31+(column-1)*15;i++ )
		{	
			if ( ranges[i] >0.05)
			{
				position_x = ranges[i] *cos(angle_min+angle_increment*(i+237) - 1.53);
				//ROS_INFO("data:%0.3f,position_x:%0.3f",ranges[i],position_x);
				value_count++;
				sum += position_x;
			}
			
		}
		if (value_count != 0)
		{
			distance = sum/value_count;
			if (distance > 0.15)
			{	
				ROS_INFO("distance:%0.3f",distance);
				return distance;
			}
			
		}
		//
		loop_rate.sleep();
	}
	return 0;	
}

double distance_adjust(ros::Publisher& cmd,float distance,bool fast_mode = false)
{
	double start_position_x,start_position_y;
	double delta_x,delta_y;
	double adjust_factor;   //距离调整因子， .05m/s 停止移动距离大约0.022m
	double target_distance = abs(distance);
	double delta_distance = 0.0;

	//打滑检测
	std_msgs::Float32 imu_base_angle_msgs; 
	std_msgs::Float32 imu_delta_angle_msgs; 

	if (target_distance <0.05)
		adjust_factor = 2.22;
	else 
	{
		if (fast_mode == true)
			adjust_factor = target_distance/(target_distance -0.100);
		else 
			adjust_factor = target_distance/(target_distance-0.022);
	}
	ROS_INFO("distance adjust %0.3f",distance);
	double current_distance = 0.0;
	bool start_flag = false;
	bool stop_flag  = false;
	ros::Rate loop_rate(60);
	int count = 0;
	while(ros::ok())
	{
		while(ros::ok())
		{
			count++;
			if (count >3)
				break;
			loop_rate.sleep();
		}
		if (!start_flag)
		{
			start_position_x = odom_msg.pose.pose.position.x;
			start_position_y = odom_msg.pose.pose.position.y;

			imu_base_angle_msgs.data = imu_angle_msgs.data;
			start_flag = true;
		}
		
		if ((sub_msg.id == 5) && (sub_msg.data[0] == 14) )
		{
			ROS_INFO("stop!!!!");
			stop_flag = true;
		}
		
		if (stop_flag == true)
		{
			speed_msgs.linear.x = 0.0;
			speed_msgs.angular.z = 0.0;
			cmd.publish(speed_msgs);
		}
		if (stop_flag == false)
		{
			if (distance > 0.0)
			{
				if (fast_mode == true)
					speed_msgs.linear.x = 0.55;
				else 
					speed_msgs.linear.x = 0.05;
			}
			else 
			{
				if (fast_mode == true)
					speed_msgs.linear.x = -0.55;
				else 
					speed_msgs.linear.x = -0.05;
			}
			
			imu_delta_angle_msgs.data = abs(imu_base_angle_msgs.data - imu_angle_msgs.data);
			
			if ( imu_delta_angle_msgs.data > 2)
			{
				//ROS_INFO("delta_angle:%0.3lf",imu_delta_angle_msgs.data);
			}

			speed_msgs.angular.z = 0.0;
			delta_x = odom_msg.pose.pose.position.x - start_position_x;
			delta_y = odom_msg.pose.pose.position.y - start_position_y;
			current_distance = sqrt(delta_x*delta_x + delta_y*delta_y);
			//ROS_INFO("distance:%0.3lf",current_distance);
			if ((current_distance*adjust_factor) >= target_distance )
			{
				speed_msgs.linear.x = 0.0;
				cmd.publish(speed_msgs);
				count=0;
				while(ros::ok())
				{
					
					if (odom_msg.twist.twist.linear.x < 0.01 && odom_msg.twist.twist.linear.x > -0.01)
					{
						delta_x = odom_msg.pose.pose.position.x - start_position_x;
						delta_y = odom_msg.pose.pose.position.y - start_position_y;
						current_distance = sqrt(delta_x*delta_x + delta_y*delta_y);
						delta_distance = target_distance - current_distance;
						ROS_INFO("delta_distance%0.3f",delta_distance);
						return delta_distance;
					}
					
					//
					loop_rate.sleep();
				}	
				break;
			}
			else 
			{
				cmd.publish(speed_msgs);
			}	
			
		}
		//
		loop_rate.sleep();
		++count;
	}
	return 0.0;
}



void move_distance(ros::Publisher& cmd,float distance,float speed = 0.55,float acc = 0.5)
{
	ros::Rate loop_rate(100);
	int count = 0;
	float acc_time = abs(speed)/acc;
	float time;
	float acc_distance = acc*acc_time * acc_time;  //*a*t2

	if (distance >= acc_distance)
		time = (acc_time + (distance - acc_distance)/abs(speed))*100;
	else 
	{
		time = sqrt(distance/acc)*100;
	}

	while(ros::ok())
	{
		if (count > time)	
			break;
		speed_msgs.linear.x = speed;
		speed_msgs.angular.z = 0.0;
		cmd.publish(speed_msgs);
		count++;
		loop_rate.sleep();
	}
	count = 0;
	while(ros::ok())
	{
		if (count > acc_time)
			break;
		speed_msgs.linear.x = 0;
		speed_msgs.angular.z = 0.0;
		cmd.publish(speed_msgs);
		count++;
		loop_rate.sleep();
	}
}




float lineFit(int column, float laser_angle_base)
{
    int count = 0;
	int value_count = 0;

    float A = 0.0;  
    float B = 0.0;  
    float C = 0.0;  
    float D = 0.0;  
    float E = 0.0;  
    float F = 0.0;
    float a, b, temp = 0; 
    float angle;
	ros::Rate loop_rate(30);
	while(ros::ok())
	{
		count++;
		if (count >10)
			break;
		//
		loop_rate.sleep();
	}
	while(ros::ok())
	{
        value_count = 0;
		for (int i =0+(column-1)*15;i < 31+(column-1)*15;i++ )
		{	
			if ( ranges[i] > 0.05)
			{
                position_x = ranges[i] *cos(angle_min+angle_increment*(i+237) - 1.53);
                position_y = ranges[i]*sin(angle_min+angle_increment*(i+237) - 1.53);
                //ROS_INFO("index:%d,data:%0.3f,x:%0.3f,y:%0.3f",i+237,ranges[i],position_x,position_y);
				 A += position_y * position_y;  
                 B += position_y;  
                 C += position_y * position_x;  
                 D += position_x; 
                value_count++;
			}	
		}
        //执行拟合  数据点position_x[value_count]，position_y[value_count] ，数量value_count
        //以position_y为横轴，position_x为纵轴
           
    // 计算斜率a和截距b 
	temp = (value_count*A - B*B);
    if( temp > 0.001 || temp < -0.001 )// 判断分母不为0  
    {  
        a = (value_count*C - B*D) / temp;  
        b = (A*D - B*C) / temp;
        angle = atan(a)*180/3.1415926 + laser_angle_base;
        ROS_INFO("angle:%0.3f",angle);
        return angle;
    }  
    else  
    {  
        a = 1;  
        b = 0; 
        return laser_angle_base; 

    }
	//
	loop_rate.sleep();
	}
	return 0;	
}

void orientation_adjust(ros::Publisher& cmd,float target_angle)
{
	ROS_INFO("angle adjust");
	ros::Rate loop_rate(60);
	unsigned int count = 0;
	//wait 1 second  in order to receice imu sensor
	while(ros::ok())
	{
		count++;
		if (count >5)
			break;
		//
		loop_rate.sleep();
	}
	ROS_INFO("angle %f",imu_angle_msgs.data);
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) > 20)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.25;
			cmd.publish(speed_msgs);
		}
		else
		{
			break;
		}
		//
		loop_rate.sleep();
	}
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) > 10)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.15;
			cmd.publish(speed_msgs);
		}
		else
		{
			break;
		}
		//
		loop_rate.sleep();
	}

	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) > 0.5)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.07;
			cmd.publish(speed_msgs);
		}	
		else
		{
			if (((imu_angle_msgs.data - target_angle) > -0.5) && (imu_angle_msgs.data - target_angle) < 0.5)
			{
				if ( count % 3 == 0)
				{
					ROS_INFO("angle %f",imu_angle_msgs.data);
				}
				speed_msgs.angular.z = 0;
				cmd.publish(speed_msgs);
				ROS_INFO("angle adjust 0");
			} 
			break;
		}
		//
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -20)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.25;
			cmd.publish(speed_msgs);
		}		
		else
		{
			break;
		}
		//
		loop_rate.sleep();
	}

	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -10)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.15;
			cmd.publish(speed_msgs);
		}		
		else
		{
			break;
		}
		//
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -0.5)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.07;
			cmd.publish(speed_msgs);
			//
		}		
		else
		{
			if (((imu_angle_msgs.data - target_angle) > -0.5) && (imu_angle_msgs.data - target_angle) < 0.5)
			{
				if ( count % 3 == 0)
				{
					ROS_INFO("angle %f",imu_angle_msgs.data);
				}
				speed_msgs.angular.z = 0;
				cmd.publish(speed_msgs);
				ROS_INFO("angle adjust 0");
			} 
			break;
		}
		//
		loop_rate.sleep();
	}
	
	if (((imu_angle_msgs.data - target_angle) > -0.5) && (imu_angle_msgs.data - target_angle) < 0.5)
	{
		if ( count % 3 == 0)
		{
			ROS_INFO("angle %f",imu_angle_msgs.data);
		}
		speed_msgs.angular.z = 0;
		cmd.publish(speed_msgs);
		ROS_INFO("angle adjust 0");
	} 
}
void orientation_adjust(ros::Publisher& cmd,float target_angle,float laser_angle)
{
	ROS_INFO("angle adjust");
	ros::Rate loop_rate(60);
	unsigned int count = 0;
	bool is_start = true;
	//wait 1 second  in order to receice imu sensor
	while(ros::ok())
	{
		count++;
		if (count >5)
			break;
		//
		loop_rate.sleep();
	}
	while(ros::ok())
	{
		count++;
		if (is_start == true)
		{
			ROS_INFO("imu_angle %0.3f,laser_angle %0.3f",imu_angle_msgs.data,laser_angle);
			target_angle = target_angle + (imu_angle_msgs.data - laser_angle);
			is_start = false;
		}
		if ((imu_angle_msgs.data - target_angle) > 10)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %0.3f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.15;
			cmd.publish(speed_msgs);
		}
		else
		{
			break;
		}
		//
		loop_rate.sleep();
	}

	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) > 0.4)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.07;
			cmd.publish(speed_msgs);
		}	
		else
		{
			if (((imu_angle_msgs.data - target_angle) > -0.4) && (imu_angle_msgs.data - target_angle) < 0.4)
			{
				if ( count % 3 == 0)
				{
					ROS_INFO("angle %f",imu_angle_msgs.data);
				}
				speed_msgs.angular.z = 0;
				cmd.publish(speed_msgs);
				ROS_INFO("angle adjust 0");
			} 
			break;
		}
		//
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -10)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.15;
			cmd.publish(speed_msgs);
		}		
		else
		{
			break;
		}
		//
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -0.4)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.07;
			cmd.publish(speed_msgs);
			//
		}		
		else
		{
			if (((imu_angle_msgs.data - target_angle) > -0.4) && (imu_angle_msgs.data - target_angle) < 0.4)
			{
				if ( count % 3 == 0)
				{
					ROS_INFO("angle %f",imu_angle_msgs.data);
				}
				speed_msgs.angular.z = 0;
				cmd.publish(speed_msgs);
				ROS_INFO("angle adjust 0");
			} 
			break;
		}
		//
		loop_rate.sleep();
	}
	
	if (((imu_angle_msgs.data - target_angle) > -0.4) && (imu_angle_msgs.data - target_angle) < 0.4)
	{
		if ( count % 3 == 0)
		{
			ROS_INFO("angle %f",imu_angle_msgs.data);
		}
		speed_msgs.angular.z = 0;
		cmd.publish(speed_msgs);
		ROS_INFO("angle adjust 0");
	} 
}
void move_front_onemeter(ros::Publisher& cmd)
{
	ROS_INFO("rotation -90degree");
	ros::Rate loop_rate(20);
	unsigned int count = 0;
	//延时6.2秒旋转-90度
	while(ros::ok())
	{
		count++;
		speed_msgs.angular.x = 0.35;
		cmd.publish(speed_msgs);
		if (count >30)
			break;
		//
		loop_rate.sleep();
	}
	count = 0;
	//延时1s,角速度变为0
	while(ros::ok())
	{
		count++;
		speed_msgs.angular.z = 0;
		cmd.publish(speed_msgs);
		if (count >2)
			break;
		//
		loop_rate.sleep();
	}

	

	
}
//旋转-90度
void rotation_90deg(ros::Publisher& cmd)
{
	ROS_INFO("rotation -90degree");
	ros::Rate loop_rate(20);
	unsigned int count = 0;
	//延时6.2秒旋转-90度
	while(ros::ok())
	{
		count++;
		speed_msgs.angular.z = -0.70;
		cmd.publish(speed_msgs);
		if (count >45)
			break;
		//
		loop_rate.sleep();
	}
	count = 0;
	//延时1s,角速度变为0
	while(ros::ok())
	{
		count++;
		speed_msgs.angular.z = 0;
		cmd.publish(speed_msgs);
		if (count >2)
			break;
		//
		loop_rate.sleep();
	}
}

void rotation_angle(ros::Publisher& cmd,float angle)
{
	ROS_INFO("rotation %0.3f",angle);
	ros::Rate loop_rate(20);
	unsigned int count = 0;
	unsigned int end_count = 45*angle/90;
	while(ros::ok())
	{
		count++;
		if (angle > 0)
		{
			speed_msgs.angular.z = 0.60;
		}
		else 
		{
			speed_msgs.angular.z = -0.60;
		}
		cmd.publish(speed_msgs);
		if (count > end_count)
			break;
		loop_rate.sleep();
	}
	count = 0;
	while(ros::ok())
	{
		count++;
		speed_msgs.angular.z = 0;
		cmd.publish(speed_msgs);
		if (count >2)
			break;
		//
		loop_rate.sleep();
	}
}


int main(int argc,char **argv)
{
	
   /*读取位置信息*******************************************************************/
	double start_pos[4];
	double grasp_pos1[4],grasp_pos2[4],grasp_pos3[4];
	double release_pos[4];
	double target_pos[20];
	int pos_num = 0;
	bool is_start_pos = true;
	//read the position of navigation from the txt file
    ifstream Object_position_file("/home/robot/position.txt");
    string temp;
    if(!Object_position_file.is_open())
    {
        cout<<"Failed to open  position file"<<endl;
		return 0;
    }

    while(getline(Object_position_file,temp))
    {
        sscanf(temp.c_str(),"%lf %lf %lf %lf",&target_pos[4*pos_num],&target_pos[4*pos_num+1],&target_pos[4*pos_num+2],&target_pos[4*pos_num+3]);
		pos_num++;
        
    }

    for(int i=0;i<pos_num;i++)
        cout<<target_pos[4*i]<<"\t"<<target_pos[4*i+1]<<"\t"<<target_pos[4*i+2]<<"\t"<<target_pos[4*i+3]<<endl;
    Object_position_file.close();
	for (int i = 0; i < 4; i++)
	{
		start_pos[i]   = target_pos[i];
		grasp_pos1[i]  = target_pos[4+i];
		grasp_pos2[i]  = target_pos[8+i];
		grasp_pos3[i]  = target_pos[12+i];
		release_pos[i] = target_pos[16+i];
	}
	cout<<grasp_pos2[0]<<"\t"<<grasp_pos2[1]<<"\t"<<grasp_pos2[2]<<"\t"<<grasp_pos2[3]<<endl;
	/*********************************************************************************************/

	ros::init(argc,argv,"navigation_task");
	ros::NodeHandle n;
	
	//任务通信
	ros::Publisher info_pub = n.advertise<id_data_msgs::ID_Data>("/notice",10);
	ros::Subscriber sub = n.subscribe("/notice", 100, infoCallback);

	//角度调节
	ros::Publisher  twist_pub = n.advertise<geometry_msgs::Twist>("/cmd_vel",10);
	ros::Subscriber imu_angle_sub = n.subscribe("/jy901b_imu/imu_angle",5,imuAngleCallback);
	ros::Subscriber odom_data = n.subscribe("/odom",10,odomCallback);
	unsigned int row_position;
	unsigned int column_position = 1;

	ros::Subscriber laser_scan_data = n.subscribe("/scan",1,laser_scanCallback);
	float laser_scan_distance = 0.0;
	float laser_scan_y_distance = 0.0;
	float delta_distance = 0.0;
	float laser_scan_angle = 0.0;

	//角度校0
	ros::ServiceClient angle_to_zero_client = n.serviceClient<std_srvs::Empty>("/jy901b_imu/set_zero_orientation");
	std_srvs::Empty srv;

	//参数设置，是否使用角度补偿，是否使用调试模式
	bool angle_adjust = false;
	bool debug_mode = false;
	double angle_base = 0.0;
	n.param<bool>("/navigation_task/angle_adjust", angle_adjust, false);
    n.param<bool>("/navigation_task/debug_mode", debug_mode, false);
	n.param<double>("/navigation_task/angle_base", angle_base, 0.0);

	
	sub_msg.id = 0;
	sub_msg.data[0] = 0;

	
     MoveBaseClient ac("move_base", true);  
	 acp = &ac;
     while(!ac.waitForServer(ros::Duration(5.0))){  
        ROS_INFO("Waiting for the move_base action server to come up");  
      }  
     move_base_msgs::MoveBaseGoal goal;  
      
	ros::Rate loop_rate(10);
	int count = 0;
	

	ros::AsyncSpinner spinner(0);

	spinner.start();
	while(ros::ok())
	{
		if ((2 == sub_msg.id) && (0 == sub_msg.data[0]) )
		{
			ROS_INFO("Need go to start positon");  //起点
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
		    //执行任务


			if (false == is_start_pos)
			{

				//通过激光雷达信息定位前方距离
				distance_adjust(twist_pub,-0.45,true); //退回
				laser_scan_distance = get_laser_length(1);
				float y_distance = 5.4 - 0.31- 0.64 - laser_scan_distance;
				float x_distance = 5.4 - 0.24 - 0.40 - LaserScan_Y_Distance();
				float sita = atan(x_distance/y_distance)*180/3.1415926 + 4;

				ROS_INFO("x Postion:%03f,y Position:%0.3f,angle:%0.3f", x_distance,y_distance,sita);
				orientation_adjust(twist_pub,-90 +sita );
				float back_distance = sqrt(x_distance*x_distance + y_distance*y_distance);

				//distance_adjust(twist_pub,move_distace-0.35);
				move_distance(twist_pub,back_distance + 0.11,-0.55,0.5);
				
				
				ROS_INFO("succeeded to move start position");
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);
				is_start_pos  = true;				
				/*
				
				rotation_90deg(twist_pub);        //旋转-90度，调整姿态
				//到达目标位置，姿态为90度
				goal.target_pose.header.frame_id = "map";  
            	goal.target_pose.header.stamp = ros::Time::now();  
				goal.target_pose.pose.position.x = start_pos[0];
	  			goal.target_pose.pose.position.y = start_pos[1];
				goal.target_pose.pose.orientation.z = start_pos[2];
     			goal.target_pose.pose.orientation.w = start_pos[3];  
				ac.sendGoal(goal);
      			ac.waitForResult();  
				
     	 		if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 		{
					if ( angle_adjust == true)
					{
						//orientation_adjust(twist_pub,0.0);
					}
					rotation_90deg(twist_pub);
      				ROS_INFO("succeeded to move start position");
            		//反馈
					pub_msg.id = 2;
					pub_msg.data[0] = 15;				
					info_pub.publish(pub_msg);
					is_start_pos  = true;
	 	 		}
     		 	else
	 	 		{
        			ROS_INFO("failed to move start position for some reason"); 
	 	 		}
				*/		
			}
			else
			{
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);
				is_start_pos  = true;
			}
			
		}


		if ((2 == sub_msg.id) && (1 == sub_msg.data[0]) )
		{
			row_position = sub_msg.data[1];
			column_position = sub_msg.data[0];
			ROS_INFO("Need go to Postion1,1");
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
			//货架第一列
			goal.target_pose.header.frame_id = "map";  
            goal.target_pose.header.stamp = ros::Time::now();  			
			if ( 1 == row_position )
			{
				goal.target_pose.pose.position.x = grasp_pos1[0] - 0.10;
			}
			else 
			{
				goal.target_pose.pose.position.x = grasp_pos1[0];
			}      
	  		goal.target_pose.pose.position.y = grasp_pos1[1];
			goal.target_pose.pose.orientation.z = grasp_pos1[2];
     		goal.target_pose.pose.orientation.w = grasp_pos1[3];      
      		ROS_INFO("Sending goal");  
      		ac.sendGoal(goal);  
      		ac.waitForResult();  
      
     	 	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 	{
				if ( angle_adjust == true)
				{
					laser_scan_angle = lineFit(1,angle_base);
					orientation_adjust(twist_pub,0.0,laser_scan_angle);	
				}
				
				/*
				Y方向调整
				laser_scan_y_distance = LaserScan_Y_Distance(1);
				ROS_INFO("laser_scan_y_distance:%0.3f",laser_scan_y_distance);
				if ( laser_scan_y_distance > 0.03 )
				{
					orientation_adjust(twist_pub,90.0);
					distance_adjust(twist_pub,laser_scan_y_distance);
					orientation_adjust(twist_pub,0);
				}
				if ( laser_scan_y_distance < -0.03 )
				{
					orientation_adjust(twist_pub,90.0);
					distance_adjust(twist_pub,laser_scan_y_distance);
					orientation_adjust(twist_pub,0);
				}
				*/

					
				//值待确定
				//laser_scan_distance = get_laser_length(1); //测量前方距离
				/*
				if ( 1 == row_position )
				{
					delta_distance = laser_scan_distance - 1.16;
				}
				if ((2 == row_position) || (3 == row_position)) 
				{
					delta_distance = laser_scan_distance - 1.14;
				}
				if ( (delta_distance > 0.02) || (delta_distance < -0.02))
				{
					//distance_adjust(twist_pub,delta_distance);
				}
				*/
				

      			ROS_INFO("succeeded to move pick position 1");
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);

				is_start_pos  = false;
	 	 	}
     		 else
	 	 	{
        		ROS_INFO("failed to move pick position 1 for some reason"); 
	 	 	}	
		}
	
		if ((2 == sub_msg.id) && (2 == sub_msg.data[0]) )
		{
			row_position = sub_msg.data[1];
			column_position = sub_msg.data[0];
			ROS_INFO("Need go to Postion1,2");
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
			//货架第二列
			goal.target_pose.header.frame_id = "map";  
            goal.target_pose.header.stamp = ros::Time::now();  
      
			if ( 1 == row_position )
			{
				goal.target_pose.pose.position.x = grasp_pos2[0] - 0.10;
			}
			else 
			{
				goal.target_pose.pose.position.x = grasp_pos2[0];
			}
	  		goal.target_pose.pose.position.y = grasp_pos2[1];
			goal.target_pose.pose.orientation.z = grasp_pos2[2];
     		goal.target_pose.pose.orientation.w = grasp_pos2[3];
      
      		ROS_INFO("Sending goal");  
      		ac.sendGoal(goal);  
      
      		ac.waitForResult();  
      
     	 	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 	{
				if ( angle_adjust == true)
				{
					laser_scan_angle = lineFit(2,angle_base);
					orientation_adjust(twist_pub,0.0,laser_scan_angle);
				}
				

				
      			ROS_INFO("succeeded to move pick position 2");
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);

				is_start_pos  = false;
	 	 	}
     		 else
	 	 	{
        		ROS_INFO("failed to move pick position 2 for some reason"); 
	 	 	}	
		}

		if ((2 == sub_msg.id) && (3 == sub_msg.data[0]) )
		{
			row_position = sub_msg.data[1];
			column_position = sub_msg.data[0];
			ROS_INFO("Need go to Postion1,3");
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
			//货架第三列
            goal.target_pose.header.frame_id = "map";  
            goal.target_pose.header.stamp = ros::Time::now();  
			
			if ( 1 == row_position )
			{
				goal.target_pose.pose.position.x = grasp_pos3[0] - 0.10;
			}
			else 
			{
				goal.target_pose.pose.position.x = grasp_pos3[0];
			}
	  		goal.target_pose.pose.position.y = grasp_pos3[1];
			goal.target_pose.pose.orientation.z = grasp_pos3[2];
     		goal.target_pose.pose.orientation.w = grasp_pos3[3]; 
      
      		ROS_INFO("Sending goal");  
      		ac.sendGoal(goal);  
      
      		ac.waitForResult();  
      
     	 	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 	{
				if ( angle_adjust == true)
				{
					laser_scan_angle = lineFit(3,angle_base);
					orientation_adjust(twist_pub,0.0,laser_scan_angle);
					//orientation_adjust(twist_pub,0.0);
				}
								
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);

				is_start_pos  = false;
	 	 	}
     		 else
	 	 	{
        		ROS_INFO("failed to move pick position 3 for some reason"); 
	 	 	}	
		}

		if ((2 == sub_msg.id) && (4 == sub_msg.data[0]) )
		{
			
			ROS_INFO("Need go to Postion2");
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
			//角度校0，去掉机械臂抓取过程中振动产生的干扰
					
			if (angle_to_zero_client.call(srv))
			{
				ROS_INFO("successed to call service");
			}
			else 
			{
				ROS_ERROR("Failed to call service");
			}


            //目标释放
			//抓取位置不变，先调整姿态
			//旋转-90度
			rotation_90deg(twist_pub);		  
      
            //到达一个临时位置，X和姿态与目标相同，Y方向有偏差
			goal.target_pose.header.frame_id = "map";  
            goal.target_pose.header.stamp = ros::Time::now();  
      
            goal.target_pose.pose.position.x = release_pos[0];
	  		goal.target_pose.pose.position.y = release_pos[1];
			goal.target_pose.pose.orientation.z = release_pos[2];
     		goal.target_pose.pose.orientation.w = release_pos[3];
				
      		ROS_INFO("Sending goal");  
      		ac.sendGoal(goal);  
      		ac.waitForResult(); 
			
     	 	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 	{
				
				//到达目标位置向前移动66cm
				//distance_adjust(twist_pub,0.52,true);
				if ( angle_adjust == true)
				{
					//orientation_adjust(twist_pub,-90);
					laser_scan_angle = lineFit(3,angle_base);
					orientation_adjust(twist_pub,-90,-90 +  laser_scan_angle);	
				}

				distance_adjust(twist_pub,0.45,true);
				
      			ROS_INFO("succeeded to move place position");
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);

				pub_msg.id = 2;
				pub_msg.data[0] = 16;				
				info_pub.publish(pub_msg);

				is_start_pos  = false;
	 	 	}
     		 else
	 	 	{
        		ROS_INFO("failed to move place position for some reason"); 
	 	 	}	
		}

		if ((2 == sub_msg.id) && (5 == sub_msg.data[0]) )
		{
			//接收的数据以厘米为单位，
			float distance = (float)sub_msg.data[1]/100;

			ROS_INFO("move forward %d",sub_msg.data[1]);
			pub_msg.id = 2;
			pub_msg.data[0] = 7;				
			info_pub.publish(pub_msg);
			
            //move forward
			ROS_INFO("Test 1");
			double delta_distance = distance_adjust(twist_pub,distance);
			 

			laser_scan_angle = lineFit(column_position,angle_base);
			orientation_adjust(twist_pub,0.0,laser_scan_angle);

			//laser_scan_distance = get_laser_length(column_position);
			ROS_INFO("Test 2");
            //反馈
			
			unsigned int move_distance= (unsigned int)(abs(delta_distance)*100);
			
			pub_msg.id = 2;
			pub_msg.data[0] = 8;
			if (delta_distance >0)
				pub_msg.data[1] = 1;
			else 
				pub_msg.data[1] = 2;
			pub_msg.data[2] = move_distance;				
			info_pub.publish(pub_msg);

			is_start_pos  = false;
		}

		if ((2 == sub_msg.id) && (6 == sub_msg.data[0]) )
		{
			//接收的数据以厘米为单位
			float distance = 0 - (float)sub_msg.data[1]/100;
			ROS_INFO("move back %d",sub_msg.data[1]);
			pub_msg.id = 2;
			pub_msg.data[0] = 7;				
			info_pub.publish(pub_msg);

            //move back
			
			double delta_distance = distance_adjust(twist_pub,distance);
			

            //反馈
			unsigned int move_distance= (unsigned int)(abs(delta_distance)*100);
			pub_msg.id = 2;
			pub_msg.data[0] = 8;
			
			if (delta_distance >0)
				pub_msg.data[1] = 1;
			else 
				pub_msg.data[1] = 2;
			pub_msg.data[2] = move_distance;				
			info_pub.publish(pub_msg);

			is_start_pos  = false;
		}
		////
		loop_rate.sleep();
		++count;
	}
	spinner.stop();
}
