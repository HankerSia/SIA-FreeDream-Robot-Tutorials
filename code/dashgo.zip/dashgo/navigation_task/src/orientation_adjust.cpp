#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>  
#include <actionlib/client/simple_action_client.h> 
#include <id_data_msgs/ID_Data.h>
#include <fstream>
#include <sstream>

#include <std_msgs/Float32.h>
#include <geometry_msgs/Twist.h>
using namespace std;



std_msgs::Float32 imu_angle_msgs;
geometry_msgs::Twist speed_msgs;


void imuAngleCallback(const std_msgs::Float32::ConstPtr& msg)
{
	imu_angle_msgs.data = msg->data;
	//ROS_INFO("angle %f",imu_angle_msgs.data);
}


void orientation_adjust(ros::Publisher& cmd,float target_angle)
{
	ROS_INFO("angle adjust");
	ros::Rate loop_rate(10);
	while(ros::ok())
	{
		if ((imu_angle_msgs.data - target_angle) > 10)
		{
			ROS_INFO("angle >10");
			speed_msgs.angular.z = -0.2;
			cmd.publish(speed_msgs);
		}
		else
		{
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}

	while(ros::ok())
	{
		if ((imu_angle_msgs.data - target_angle) > 1)
		{
			ROS_INFO("angle adjust > 1");
			speed_msgs.angular.z = -0.1;
			cmd.publish(speed_msgs);
		}	
		else
		{
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		if ((imu_angle_msgs.data - target_angle) < -10)
		{
			ROS_INFO("angle < -10");
			speed_msgs.angular.z = 0.2;
			cmd.publish(speed_msgs);
		}		
		else
		{
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		if ((imu_angle_msgs.data - target_angle) < -1)
		{
			ROS_INFO("angle adjust < -1");
			speed_msgs.angular.z = 0.1;
			cmd.publish(speed_msgs);
			ros::spinOnce();
		}		
		else
		{
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	if (((imu_angle_msgs.data - target_angle) > -1.0) && (imu_angle_msgs.data - target_angle) < 1.0)
	{
		speed_msgs.angular.z = 0;
		cmd.publish(speed_msgs);
		ROS_INFO("angle adjust");
	} 
}



int main(int argc,char **argv)
{
	
	ros::init(argc,argv,"orientation_adjust");
	ros::NodeHandle n;
	

	ros::Publisher  twist_pub = n.advertise<geometry_msgs::Twist>("/cmd_vel",10);
	ros::Subscriber imu_angle_sub = n.subscribe("/urnaus_imu/imu_angle",1,imuAngleCallback); 
      
  
	


	ros::Rate loop_rate(10);
	
	while(ros::ok())
	{
		
		orientation_adjust(twist_pub,0.0);
		ros::spinOnce();
		loop_rate.sleep();
		
	}
}
