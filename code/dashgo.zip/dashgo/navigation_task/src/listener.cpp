#include "ros/ros.h"
#include "id_data_msgs/ID_Data.h"


void infoCallback(const id_data_msgs::ID_Data::ConstPtr& msg)
{
  ROS_INFO("I heard: [%d]", msg->id);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "info_listener");

  
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("/notice/kinect2ugv", 100, infoCallback);

  ros::spin();

  return 0;
}

