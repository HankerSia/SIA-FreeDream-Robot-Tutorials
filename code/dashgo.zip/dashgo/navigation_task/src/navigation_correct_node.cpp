#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>  
#include <actionlib/client/simple_action_client.h> 
#include <id_data_msgs/ID_Data.h>
#include <fstream>
#include <sstream>

#include <std_msgs/Float32.h>
#include <geometry_msgs/Twist.h>
#include <std_srvs/Empty.h>
#include "sensor_msgs/LaserScan.h"
#include <nav_msgs/Odometry.h>

#include <math.h>
using namespace std;
typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

id_data_msgs::ID_Data pub_msg;
id_data_msgs::ID_Data sub_msg;


std_msgs::Float32 imu_angle_msgs;     //订阅的角度信息
geometry_msgs::Twist speed_msgs;      //发送的速度控制信息
nav_msgs::Odometry odom_msg;          //订阅的里程信息

/**********************************/
//订阅的激光扫描相关数据
float angle_min;
float angle_max;
float angle_increment;
float range_min;
float range_max;

//只取+-30度的数据
float ranges[61];   //测试前方角度，距离
float ranges_y[20]; //测试Y方向距离

float position_x;
float position_y;
/**********************************/

void infoCallback(const id_data_msgs::ID_Data::ConstPtr& msg)
{
  	sub_msg.id = msg->id;
  	sub_msg.data[0] = msg->data[0];
	if ((msg->id ==2) && (msg->data[0] < 7) && (msg->data[0] > 0))
	{
		sub_msg.data[1] = msg->data[1];
	}
  	
  	//ROS_INFO("msg->data[0]: %d,msg->data[1]: %d",sub_msg.data[0],sub_msg.data[1]);
}

void imuAngleCallback(const std_msgs::Float32::ConstPtr& msg)
{
	imu_angle_msgs.data = msg->data;
	if ((imu_angle_msgs.data >= -180) && (imu_angle_msgs.data < -90))
	{
		imu_angle_msgs.data += 360;
	}
}
void odomCallback(const nav_msgs::Odometry::ConstPtr& msg )
{
	odom_msg.pose.pose.position.x = msg->pose.pose.position.x;
	odom_msg.pose.pose.position.y = msg->pose.pose.position.y;
}
void laser_scanCallback(const sensor_msgs::LaserScan::ConstPtr& msg )
{
	angle_min = msg->angle_min;
    angle_increment = msg->angle_increment;

	//获取X方向和角度的测距信息
    for (int i = 0;i< 61;i++)
    {
        if (msg->intensities[i+237] > 1)
        {
			ranges[i] = msg->ranges[i+237];
			//position_x = msg->ranges[i+237] *cos(angle_min+angle_increment*(i+237) - 1.53);
			//position_y = msg->ranges[i+237] *sin(angle_min+angle_increment*(i+237) - 1.53);
            //ROS_INFO("index:%d,x:%0.3f,y:%0.3f",i+237,position_x,position_y);
        }
		else 
		{
			ranges[i] = 0;
		}
    }


	//获取Y方向距离的测距信息
	for (int i = 0;i< 20;i++)
    {
        if (msg->intensities[i+340] > 1)
        {
			ranges_y[i] = msg->ranges[i+340] * sin(angle_min+angle_increment*(i+340) - 1.53);
            //ROS_INFO("index:%d,data:%0.3f,y:%0.3f",i+340,msg->ranges[i+340],ranges_y[i]);
        }
		else 
		{
			ranges_y[i] = 0;
		}
    }

}

float LaserScan_Y_Distance(int column)
{
    int count = 0;
	int value_count = 0;

    float base_distance = 0.717;   //需要标定
    float target_distance;

    float distance;
    float sum = 0;
    if (column == 1)
        target_distance = base_distance;
    if (column == 2)
        target_distance = base_distance + 0.387 ;
    if (column == 3)
        target_distance = base_distance + 0.387*2 ; 

	ros::Rate loop_rate(30);
	while(ros::ok())
	{
		count++;
		if (count >30)
			break;
		ros::spinOnce();
		loop_rate.sleep();
	}
	while(ros::ok())
	{
        value_count = 0;
		for (int i =0;i < 20; i++)
		{	
			if ( (ranges_y[i] > (target_distance - 0.30)) && (ranges_y[i] < (target_distance + 0.30)) )
			{
                sum += ranges_y[i];
                value_count++;
			}	
		}
        distance  = sum / value_count;
        if ( (distance > 0.2) && (distance < 2.4) ) 
		{
			ROS_INFO("Y_Distance:%0.3f", distance);
            break;
		}
			
	ros::spinOnce();
	loop_rate.sleep();
	}
	return distance;	
}
//获取激光雷达测距信息，
float get_laser_length(int column)
{
	float sum = 0.0;
	float distance;
	int count = 0;
	int value_count = 0;
	ros::Rate loop_rate(30);
	while(ros::ok())
	{
		count++;
		if (count >60)
			break;
		ros::spinOnce();
		loop_rate.sleep();
	}
	while(ros::ok())
	{
		for (int i =0+(column-1)*15;i < 31+(column-1)*15;i++ )
		{	
			if ( ranges[i] >0.05)
			{
				position_x = ranges[i] *cos(angle_min+angle_increment*(i+237) - 1.53);
				//ROS_INFO("data:%0.3f,position_x:%0.3f",ranges[i],position_x);
				value_count++;
				sum += position_x;
			}
			
		}
		if (value_count != 0)
		{
			distance = sum/value_count;
			if (distance > 0.15)
			{	
				ROS_INFO("distance:%0.3f",distance);
				return distance;
			}
			
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	return 0;	
}
void distance_adjust(ros::Publisher& cmd,float distance)
{
	double start_position_x;
	double start_position_y;
	double delta_x;
	double delta_y;
	double target_distance = abs(distance);
	ROS_INFO("distance adjust %0.3f",distance);
	double current_distance = 0.0;
	bool start_flag = false;
	bool stop_flag  = false;
	ros::Rate loop_rate(60);
	int count = 0;
	while(ros::ok())
	{
		while(ros::ok())
		{
			count++;
			if (count >60)
				break;
			ros::spinOnce();
			loop_rate.sleep();
		}
		if (!start_flag)
		{
			start_position_x = odom_msg.pose.pose.position.x;
			start_position_y = odom_msg.pose.pose.position.y;
			start_flag = true;
		}
		if ((sub_msg.id == 1) && (sub_msg.data[0] == 13) )
		{
			ROS_INFO("stop!!!!");
			stop_flag = true;
		}
		if (stop_flag == true)
		{
			speed_msgs.linear.x = 0.0;
			speed_msgs.angular.z = 0.0;
			cmd.publish(speed_msgs);
		}
		if (stop_flag == false)
		{
			if (distance > 0.0)
			{
				speed_msgs.linear.x = 0.05;
			}
			else 
			{
				speed_msgs.linear.x = -0.05;
			}

			speed_msgs.angular.z = 0.0;
			
			delta_x = odom_msg.pose.pose.position.x - start_position_x;
			delta_y = odom_msg.pose.pose.position.y - start_position_y;
			current_distance = sqrt(delta_x*delta_x + delta_y*delta_y);
			ROS_INFO("distance:%0.3lf",current_distance);
			if ((current_distance*1.28) >= target_distance )
			{
				speed_msgs.linear.x = 0.0;
				cmd.publish(speed_msgs);
				break;
			}
			else 
			{
				cmd.publish(speed_msgs);
			}	
			
		}
		ros::spinOnce();
		loop_rate.sleep();
		++count;
	}
}

float lineFit(int column)
{
    int count = 0;
	int value_count = 0;

    float A = 0.0;  
    float B = 0.0;  
    float C = 0.0;  
    float D = 0.0;  
    float E = 0.0;  
    float F = 0.0;
    float a, b, temp = 0; 
    float angle;
	ros::Rate loop_rate(30);
	while(ros::ok())
	{
		count++;
		if (count >60)
			break;
		ros::spinOnce();
		loop_rate.sleep();
	}
	while(ros::ok())
	{
        value_count = 0;
		for (int i =0+(column-1)*15;i < 31+(column-1)*15;i++ )
		{	
			if ( ranges[i] > 0.05)
			{
                position_x = ranges[i] *cos(angle_min+angle_increment*(i+237) - 1.53);
                position_y = ranges[i]*sin(angle_min+angle_increment*(i+237) - 1.53);
                //ROS_INFO("index:%d,data:%0.3f,x:%0.3f,y:%0.3f",i+237,ranges[i],position_x,position_y);
				 A += position_y * position_y;  
                 B += position_y;  
                 C += position_y * position_x;  
                 D += position_x; 
                value_count++;
			}	
		}
        //执行拟合  数据点position_x[value_count]，position_y[value_count] ，数量value_count
        //以position_y为横轴，position_x为纵轴
           
    // 计算斜率a和截距b 
    if( temp = (value_count*A - B*B) )// 判断分母不为0  
    {  
        a = (value_count*C - B*D) / temp;  
        b = (A*D - B*C) / temp;
        angle = atan(a)*180/3.1415926 + 0.2;
        ROS_INFO("angle:%0.3f",angle);
        return angle;
    }  
    else  
    {  
        a = 1;  
        b = 0; 
        break; 

    }
	ros::spinOnce();
	loop_rate.sleep();
	}
	return 0;	
}




void orientation_adjust(ros::Publisher& cmd,float target_angle)
{
	ROS_INFO("angle adjust");
	ros::Rate loop_rate(60);
	unsigned int count = 0;
	//wait 1 second  in order to receice imu sensor
	while(ros::ok())
	{
		count++;
		if (count >60)
			break;
		ros::spinOnce();
		loop_rate.sleep();
	}
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) > 10)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.15;
			cmd.publish(speed_msgs);
		}
		else
		{
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}

	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) > 0.5)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.07;
			cmd.publish(speed_msgs);
		}	
		else
		{
			if (((imu_angle_msgs.data - target_angle) > -0.5) && (imu_angle_msgs.data - target_angle) < 0.5)
			{
				if ( count % 3 == 0)
				{
					ROS_INFO("angle %f",imu_angle_msgs.data);
				}
				speed_msgs.angular.z = 0;
				cmd.publish(speed_msgs);
				ROS_INFO("angle adjust 0");
			} 
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -10)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.15;
			cmd.publish(speed_msgs);
		}		
		else
		{
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -0.5)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.07;
			cmd.publish(speed_msgs);
			ros::spinOnce();
		}		
		else
		{
			if (((imu_angle_msgs.data - target_angle) > -0.5) && (imu_angle_msgs.data - target_angle) < 0.5)
			{
				if ( count % 3 == 0)
				{
					ROS_INFO("angle %f",imu_angle_msgs.data);
				}
				speed_msgs.angular.z = 0;
				cmd.publish(speed_msgs);
				ROS_INFO("angle adjust 0");
			} 
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	if (((imu_angle_msgs.data - target_angle) > -0.5) && (imu_angle_msgs.data - target_angle) < 0.5)
	{
		if ( count % 3 == 0)
		{
			ROS_INFO("angle %f",imu_angle_msgs.data);
		}
		speed_msgs.angular.z = 0;
		cmd.publish(speed_msgs);
		ROS_INFO("angle adjust 0");
	} 
}
void orientation_adjust(ros::Publisher& cmd,float target_angle,float laser_angle)
{
	ROS_INFO("angle adjust");
	ros::Rate loop_rate(60);
	unsigned int count = 0;
	bool is_start = true;
	//wait 1 second  in order to receice imu sensor
	while(ros::ok())
	{
		count++;
		if (count >90)
			break;
		ros::spinOnce();
		loop_rate.sleep();
	}
	while(ros::ok())
	{
		count++;
		if (is_start == true)
		{
			ROS_INFO("imu_angle %0.3f,laser_angle %0.3f",imu_angle_msgs.data,laser_angle);
			target_angle = target_angle + (imu_angle_msgs.data - laser_angle);
			is_start = false;
		}
		if ((imu_angle_msgs.data - target_angle) > 10)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %0.3f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.15;
			cmd.publish(speed_msgs);
		}
		else
		{
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}

	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) > 0.4)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = -0.07;
			cmd.publish(speed_msgs);
		}	
		else
		{
			if (((imu_angle_msgs.data - target_angle) > -0.4) && (imu_angle_msgs.data - target_angle) < 0.4)
			{
				if ( count % 3 == 0)
				{
					ROS_INFO("angle %f",imu_angle_msgs.data);
				}
				speed_msgs.angular.z = 0;
				cmd.publish(speed_msgs);
				ROS_INFO("angle adjust 0");
			} 
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -10)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.15;
			cmd.publish(speed_msgs);
		}		
		else
		{
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	while(ros::ok())
	{
		count++;
		if ((imu_angle_msgs.data - target_angle) < -0.4)
		{
			if ( count % 3 == 0)
			{
				ROS_INFO("angle %f",imu_angle_msgs.data);
			}
			speed_msgs.angular.z = 0.07;
			cmd.publish(speed_msgs);
			ros::spinOnce();
		}		
		else
		{
			if (((imu_angle_msgs.data - target_angle) > -0.4) && (imu_angle_msgs.data - target_angle) < 0.4)
			{
				if ( count % 3 == 0)
				{
					ROS_INFO("angle %f",imu_angle_msgs.data);
				}
				speed_msgs.angular.z = 0;
				cmd.publish(speed_msgs);
				ROS_INFO("angle adjust 0");
			} 
			break;
		}
		ros::spinOnce();
		loop_rate.sleep();
	}
	
	if (((imu_angle_msgs.data - target_angle) > -0.4) && (imu_angle_msgs.data - target_angle) < 0.4)
	{
		if ( count % 3 == 0)
		{
			ROS_INFO("angle %f",imu_angle_msgs.data);
		}
		speed_msgs.angular.z = 0;
		cmd.publish(speed_msgs);
		ROS_INFO("angle adjust 0");
	} 
}



int main(int argc,char **argv)
{
	
   /*读取位置信息*******************************************************************/
	double start_pos[4];
	double grasp_pos1[4];
	double grasp_pos2[4];
	double grasp_pos3[4];
	double release_pos[4];
	double target_pos[20];
	int pos_num = 0;
	bool is_start_pos = true;
	//read the position of navigation from the txt file
    ifstream Object_position_file("/home/robot/position.txt");
    string temp;
    if(!Object_position_file.is_open())
    {
        cout<<"Failed to open  position file"<<endl;
		return 0;
    }

    while(getline(Object_position_file,temp))
    {
        sscanf(temp.c_str(),"%lf %lf %lf %lf",&target_pos[4*pos_num],&target_pos[4*pos_num+1],&target_pos[4*pos_num+2],&target_pos[4*pos_num+3]);
		pos_num++;
        
    }

    for(int i=0;i<pos_num;i++)
        cout<<target_pos[4*i]<<"\t"<<target_pos[4*i+1]<<"\t"<<target_pos[4*i+2]<<"\t"<<target_pos[4*i+3]<<endl;
    Object_position_file.close();
	for (int i = 0; i < 4; i++)
	{
		start_pos[i]   = target_pos[i];
		grasp_pos1[i]  = target_pos[4+i];
		grasp_pos2[i]  = target_pos[8+i];
		grasp_pos3[i]  = target_pos[12+i];
		release_pos[i] = target_pos[16+i];
	}
	cout<<grasp_pos2[0]<<"\t"<<grasp_pos2[1]<<"\t"<<grasp_pos2[2]<<"\t"<<grasp_pos2[3]<<endl;
	/*********************************************************************************************/

	ros::init(argc,argv,"navigation_task_correct");
	ros::NodeHandle n;
	
	//任务通信
	ros::Publisher info_pub = n.advertise<id_data_msgs::ID_Data>("/notice",10);
	ros::Subscriber sub = n.subscribe("/notice", 100, infoCallback);

	//角度调节
	ros::Publisher  twist_pub = n.advertise<geometry_msgs::Twist>("/cmd_vel",10);
	ros::Subscriber imu_angle_sub = n.subscribe("/jy901b_imu/imu_angle",5,imuAngleCallback);
	ros::Subscriber odom_data = n.subscribe("/odom",10,odomCallback);

	ros::Subscriber laser_scan_data = n.subscribe("/scan",1,laser_scanCallback);
	float laser_scan_distance = 0.0;
	float laser_scan_y_distance = 0.0;
	float delta_distance = 0.0;
	float laser_scan_angle = 0.0;

	//角度校0
	ros::ServiceClient angle_to_zero_client = n.serviceClient<std_srvs::Empty>("/jy901b_imu/set_zero_orientation");
	std_srvs::Empty srv;

	//参数设置，是否使用角度补偿，是否使用调试模式
	bool angle_adjust = false;
	bool debug_mode = false;
	n.param<bool>("/navigation_task/angle_adjust", angle_adjust, false);
    n.param<bool>("/navigation_task/debug_mode", debug_mode, false);

	
	sub_msg.id = 0;
	sub_msg.data[0] = 0;

	
     MoveBaseClient ac("move_base", true);  
     while(!ac.waitForServer(ros::Duration(5.0))){  
        ROS_INFO("Waiting for the move_base action server to come up");  
      }  
     move_base_msgs::MoveBaseGoal goal;  
      
	ros::Rate loop_rate(10);
	int count = 0;
	
	while(ros::ok())
	{
		if ((2 == sub_msg.id) && (0 == sub_msg.data[0]) )
		{
			ROS_INFO("Need go to start positon");
			//起点
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
		    //执行任务
			
			if (false == is_start_pos)
			{
				

				ROS_INFO("Sending goal"); 
				
				goal.target_pose.header.frame_id = "map";  
            	goal.target_pose.header.stamp = ros::Time::now();  
				goal.target_pose.pose.position.x = start_pos[0];
	  			goal.target_pose.pose.position.y = start_pos[1];
				goal.target_pose.pose.orientation.z = start_pos[2];
     			goal.target_pose.pose.orientation.w = start_pos[3];  

				ac.sendGoal(goal);
      			ac.waitForResult();  
				
     	 		if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 		{
					if ( angle_adjust == true)
					{
						//orientation_adjust(twist_pub,0.0);
					}

                     //校准里程计
                    //激光测量前方角度
                    laser_scan_angle = int((lineFit(1)+90)*314/180);
                    int x_distance = (int)(get_laser_length(1)*100);
                    int y_distance = (int)(LaserScan_Y_Distance(1)*100);
                    pub_msg.id = 2;
					pub_msg.data[0] = 9;
                    pub_msg.data[1] = x_distance;
                    pub_msg.data[1] = y_distance;
                    pub_msg.data[1] = laser_scan_angle;				
					info_pub.publish(pub_msg);
                        //激光测量前方距离
                        //激光测量侧面距离

					int sleep_count = 0;


					while(ros::ok())
					{
						sleep_count++;
						if (count >10)
						break;
						ros::spinOnce();
						loop_rate.sleep();
					}
      				ROS_INFO("succeeded to move start position");
            		//反馈
					pub_msg.id = 2;
					pub_msg.data[0] = 15;				
					info_pub.publish(pub_msg);
					is_start_pos  = true;
	 	 		}
     		 	else
	 	 		{
        			ROS_INFO("failed to move start position for some reason"); 
	 	 		}		
			}
			else
			{
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);
				is_start_pos  = true;
			}
			
		}


		if ((2 == sub_msg.id) && (1 == sub_msg.data[0]) )
		{
			unsigned int row_position = sub_msg.data[1];
			ROS_INFO("Need go to Postion1,1");
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
			//货架第一列
			goal.target_pose.header.frame_id = "map";  
            goal.target_pose.header.stamp = ros::Time::now();  
			
			if ( 1 == row_position )
			{
				goal.target_pose.pose.position.x = grasp_pos1[0] - 0.10;
			}
			else 
			{
				goal.target_pose.pose.position.x = grasp_pos1[0];
			}      
	  		goal.target_pose.pose.position.y = grasp_pos1[1];
			goal.target_pose.pose.orientation.z = grasp_pos1[2];
     		goal.target_pose.pose.orientation.w = grasp_pos1[3]; 
      
      		ROS_INFO("Sending goal");  
      		ac.sendGoal(goal);  
      
      		ac.waitForResult();  
      
     	 	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 	{
				if ( angle_adjust == true)
				{
					laser_scan_angle = lineFit(1);
					orientation_adjust(twist_pub,0.0,laser_scan_angle);
					//orientation_adjust(twist_pub,0.0);
					
				}
				
				laser_scan_distance = get_laser_length(1);

				/*
				Y方向调整
				laser_scan_y_distance = LaserScan_Y_Distance(1);
				ROS_INFO("laser_scan_y_distance:%0.3f",laser_scan_y_distance);
				if ( laser_scan_y_distance > 0.03 )
				{
					orientation_adjust(twist_pub,90.0);
					distance_adjust(twist_pub,laser_scan_y_distance);
					orientation_adjust(twist_pub,0);
				}
				if ( laser_scan_y_distance < -0.03 )
				{
					orientation_adjust(twist_pub,90.0);
					distance_adjust(twist_pub,laser_scan_y_distance);
					orientation_adjust(twist_pub,0);
				}
				*/

				/*	
				//值待确定
				ROS_INFO("sub_msg.data[1]:%d",row_position);
				if ( 1 == row_position )
				{
					delta_distance = laser_scan_distance - 1.16;
				}
				if ((2 == row_position) || (3 == row_position)) 
				{
					delta_distance = laser_scan_distance - 1.14;
				}
				if ( (delta_distance > 0.02) || (delta_distance < -0.02))
				{
					//distance_adjust(twist_pub,delta_distance);
				}
				*/
				

      			ROS_INFO("succeeded to move pick position 1");
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);

				is_start_pos  = false;
	 	 	}
     		 else
	 	 	{
        		ROS_INFO("failed to move pick position 1 for some reason"); 
	 	 	}	
		}
	
		if ((2 == sub_msg.id) && (2 == sub_msg.data[0]) )
		{
			unsigned int row_position = sub_msg.data[1];
			ROS_INFO("Need go to Postion1,2");
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
			//货架第二列
			goal.target_pose.header.frame_id = "map";  
            goal.target_pose.header.stamp = ros::Time::now();  
      
			if ( 1 == row_position )
			{
				goal.target_pose.pose.position.x = grasp_pos2[0] - 0.10;
			}
			else 
			{
				goal.target_pose.pose.position.x = grasp_pos2[0];
			}
	  		goal.target_pose.pose.position.y = grasp_pos2[1];
			goal.target_pose.pose.orientation.z = grasp_pos2[2];
     		goal.target_pose.pose.orientation.w = grasp_pos2[3];
      
      		ROS_INFO("Sending goal");  
      		ac.sendGoal(goal);  
      
      		ac.waitForResult();  
      
     	 	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 	{
				if ( angle_adjust == true)
				{
					laser_scan_angle = lineFit(2);
					orientation_adjust(twist_pub,0.0,laser_scan_angle);
					//orientation_adjust(twist_pub,0.0);
				}
				
								/*
				Y方向调整
				laser_scan_y_distance = LaserScan_Y_Distance(1);
				ROS_INFO("laser_scan_y_distance:%0.3f",laser_scan_y_distance);
				if ( laser_scan_y_distance > 0.03 )
				{
					orientation_adjust(twist_pub,90.0);
					distance_adjust(twist_pub,laser_scan_y_distance);
					orientation_adjust(twist_pub,0);
				}
				if ( laser_scan_y_distance < -0.03 )
				{
					orientation_adjust(twist_pub,90.0);
					distance_adjust(twist_pub,laser_scan_y_distance);
					orientation_adjust(twist_pub,0);
				}
				*/


				/*
				laser_scan_distance = get_laser_length(2);
				
				ROS_INFO("sub_msg.data[1]:%d",row_position);
				if ( 1 == row_position )
				{
					delta_distance = laser_scan_distance - 1.16;
				}
				if ((2 == row_position) || (3 == row_position)) 
				{
					delta_distance = laser_scan_distance - 1.14;
				}
				if ( (delta_distance > 0.02) || (delta_distance < -0.02))
				{
					//distance_adjust(twist_pub,delta_distance);
				}
				*/
				


      			ROS_INFO("succeeded to move pick position 2");
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);

				is_start_pos  = false;
	 	 	}
     		 else
	 	 	{
        		ROS_INFO("failed to move pick position 2 for some reason"); 
	 	 	}	
		}

		if ((2 == sub_msg.id) && (3 == sub_msg.data[0]) )
		{
			unsigned int row_position = sub_msg.data[1];
			ROS_INFO("Need go to Postion1,3");
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
			//货架第三列
            goal.target_pose.header.frame_id = "map";  
            goal.target_pose.header.stamp = ros::Time::now();  
			
			if ( 1 == row_position )
			{
				goal.target_pose.pose.position.x = grasp_pos3[0] - 0.10;
			}
			else 
			{
				goal.target_pose.pose.position.x = grasp_pos3[0];
			}
	  		goal.target_pose.pose.position.y = grasp_pos3[1];
			goal.target_pose.pose.orientation.z = grasp_pos3[2];
     		goal.target_pose.pose.orientation.w = grasp_pos3[3]; 
      
      		ROS_INFO("Sending goal");  
      		ac.sendGoal(goal);  
      
      		ac.waitForResult();  
      
     	 	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 	{
				if ( angle_adjust == true)
				{
					laser_scan_angle = lineFit(3);
					orientation_adjust(twist_pub,0.0,laser_scan_angle);
					//orientation_adjust(twist_pub,0.0);
				}
				
				/*
				Y方向调整
				laser_scan_y_distance = LaserScan_Y_Distance(1);
				ROS_INFO("laser_scan_y_distance:%0.3f",laser_scan_y_distance);
				if ( laser_scan_y_distance > 0.03 )
				{
					orientation_adjust(twist_pub,90.0);
					distance_adjust(twist_pub,laser_scan_y_distance);
					orientation_adjust(twist_pub,0);
				}
				if ( laser_scan_y_distance < -0.03 )
				{
					orientation_adjust(twist_pub,90.0);
					distance_adjust(twist_pub,laser_scan_y_distance);
					orientation_adjust(twist_pub,0);
				}
				*/

				/*
				laser_scan_distance = get_laser_length(3);
				
				ROS_INFO("sub_msg.data[1]:%d",row_position);
				if ( 1 == row_position )
				{
					delta_distance = laser_scan_distance - 1.16;
				}
				if ((2 == row_position) || (3 == row_position)) 
				{
					delta_distance = laser_scan_distance - 1.14;
				}
				if ( (delta_distance > 0.02) || (delta_distance < -0.02))
				{
					//distance_adjust(twist_pub,delta_distance);
				}
				*/
				
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);

				is_start_pos  = false;
	 	 	}
     		 else
	 	 	{
        		ROS_INFO("failed to move pick position 3 for some reason"); 
	 	 	}	
		}

		if ((2 == sub_msg.id) && (4 == sub_msg.data[0]) )
		{
			
			ROS_INFO("Need go to Postion2");
			pub_msg.id = 2;
			pub_msg.data[0] = 14;				
			info_pub.publish(pub_msg);
			//角度校0，去掉机械臂抓取过程中振动产生的干扰
					
			if (angle_to_zero_client.call(srv))
			{
				ROS_INFO("successed to call service");
			}
			else 
			{
				ROS_ERROR("Failed to call service");
			}
            //目标释放
			goal.target_pose.header.frame_id = "map";  
            goal.target_pose.header.stamp = ros::Time::now();  
      
            goal.target_pose.pose.position.x = release_pos[0];
	  		goal.target_pose.pose.position.y = release_pos[1];
			goal.target_pose.pose.orientation.z = release_pos[2];
     		goal.target_pose.pose.orientation.w = release_pos[3];
      
      		ROS_INFO("Sending goal");  
      		ac.sendGoal(goal);  
      
      		ac.waitForResult();  
      
     	 	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	 	 	{
				if ( angle_adjust == true)
				{
					orientation_adjust(twist_pub,180.0);
				}
      			ROS_INFO("succeeded to move place position");
            	//反馈
				pub_msg.id = 2;
				pub_msg.data[0] = 15;				
				info_pub.publish(pub_msg);

				is_start_pos  = false;
	 	 	}
     		 else
	 	 	{
        		ROS_INFO("failed to move place position for some reason"); 
	 	 	}	
		}

		if ((2 == sub_msg.id) && (5 == sub_msg.data[0]) )
		{
			//接收的数据以厘米为单位，
			float distance = (float)sub_msg.data[1]/100;

			ROS_INFO("move forward %d",sub_msg.data[1]);
			pub_msg.id = 2;
			pub_msg.data[0] = 7;				
			info_pub.publish(pub_msg);
			
            //move forward
			distance_adjust(twist_pub,distance);
      
            //反馈
			pub_msg.id = 2;
			pub_msg.data[0] = 8;				
			info_pub.publish(pub_msg);

			is_start_pos  = false;
		}

		if ((2 == sub_msg.id) && (6 == sub_msg.data[0]) )
		{
			//接收的数据以厘米为单位
			float distance = 0 - (float)sub_msg.data[1]/100;
			ROS_INFO("move back %d",sub_msg.data[1]);
			pub_msg.id = 2;
			pub_msg.data[0] = 7;				
			info_pub.publish(pub_msg);

            //move back
			
			distance_adjust(twist_pub,distance);
      
            //反馈
			pub_msg.id = 2;
			pub_msg.data[0] = 8;				
			info_pub.publish(pub_msg);

			is_start_pos  = false;
		}
		ros::spinOnce();
		loop_rate.sleep();
		++count;
	}
}
