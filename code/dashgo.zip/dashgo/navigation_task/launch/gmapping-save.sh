#!/bin/bash
rosrun map_server map_saver -f ~/catkin_ws/src/dashgo/dashgo_nav/maps/mymap

