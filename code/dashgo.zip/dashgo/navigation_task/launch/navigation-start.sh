#!/bin/bash
clear
roslaunch navigation_task navigation_imu.launch
