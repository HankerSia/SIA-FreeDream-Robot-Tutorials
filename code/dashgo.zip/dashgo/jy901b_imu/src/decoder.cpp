#include <jy901b_imu/decoder.h>
#include "stdio.h"
#include <string.h>

unsigned char Decoder::byteAnalysisCall(const unsigned char rx_byte)
{
    unsigned char package_update=0;
    unsigned char receive_message_update=0;
    
    receive_message_update=receiveFiniteStates(rx_byte) ;  //Jump communication status
    //printf("%02x ",rx_byte);
    if( receive_message_update ==1 )
    {
        receive_message_update = 0;
        package_update=packageAnalysis();
       
        return package_update;
    }
    return 0;
}


unsigned char Decoder::receiveFiniteStates(const unsigned char rx_data)
{
    switch (receive_state_)
    {
    	case kStatus_Idle:
             if (rx_data == 0x55)
             {
                header[0] = 0x55;
             	receive_state_ = KStatus_DataType;
                
             }
             break;
        case KStatus_DataType:
             if ((rx_data == 0x51) || (rx_data == 0x52) || (rx_data == 0x53)  || (rx_data == 0x54)) 
             {  
                 header[1] = rx_data;
                 receive_state_ = kStatus_Data;
             }
             else
             {
                 receive_state_ = kStatus_Idle;
             }
             break;
        case kStatus_Data:
             DataBuf[DataCounter++] = rx_data;
             if (DataCounter >= DataLen)
             {
                 DataCounter = 0;
		 	     receive_state_ = KStatus_Check;
             }
             else 
             {
                 receive_state_ = kStatus_Data;
             }
             break;
        case KStatus_Check:
            CRCReceived = rx_data;
            CRCCalculated = crcCheck(header,2,DataBuf,8);
            if ( CRCReceived == CRCCalculated )
            {
                receive_state_ = kStatus_Idle;
		        return 1;
            }
            else 
            {

            }
            receive_state_ = kStatus_Idle;
    }
    return 0;
}

unsigned char Decoder::packageAnalysis(void)
{
    unsigned char dataType = header[1];
	switch (dataType)
	{
		case (unsigned char)kItemAccRaw:
			stcAcc.a[0] = (short)(DataBuf[0] + (DataBuf[1] << 8))*16*9.8/32768;
			stcAcc.a[1] = (short)(DataBuf[2] + (DataBuf[3] << 8))*16*9.8/32768;
			stcAcc.a[2] = (short)(DataBuf[4] + (DataBuf[5] << 8))*16*9.8/32768;
            stcAcc.T = (short)(DataBuf[6] + (DataBuf[7] << 8))/100.0;
			return 1;
		case (unsigned char)kItemGyoRaw:
			stcGyro.w[0] = (short)(DataBuf[0] + (DataBuf[1] << 8))*2000/32768.0;
			stcGyro.w[1] = (short)(DataBuf[2] + (DataBuf[3] << 8))*2000/32768.0;
			stcGyro.w[2] = (short)(DataBuf[4] + (DataBuf[5] << 8))*2000/32768.0;
            stcGyro.T = (short)(DataBuf[6] + (DataBuf[7] << 8))/100.0;
			return 1;
        case (unsigned char)kItemAtdE:
            stcAngle.Angle[0] = (float)(short)(DataBuf[0] + (short)(DataBuf[1] << 8))*180.0/32768.0;
			stcAngle.Angle[1] = (float)(short)(DataBuf[2] + (short)(DataBuf[3] << 8))*180.0/32768.0;
			stcAngle.Angle[2] = (float)(short)(DataBuf[4] + (short)(DataBuf[5] << 8))*180.0/32768.0;
            stcAngle.T = (short)(DataBuf[6] + (DataBuf[7] << 8))/100.0;
            //printf("RPY:%x,%x  ",DataBuf[offset + 5],DataBuf[offset + 6]);
            //printf("RPY:%f,%f,%f\r\n",AtdE[0],AtdE[1],AtdE[2]);
            return 1;
		case (unsigned char)kItemMagRaw:
			stcMag.h[0] = (short)(DataBuf[0] + (DataBuf[1] << 8));
			stcMag.h[1] = (short)(DataBuf[2] + (DataBuf[3] << 8));
			stcMag.h[2] = (short)(DataBuf[4] + (DataBuf[5] << 8));
            stcMag.T = (short)(DataBuf[6] + (DataBuf[7] << 8))/100.0;
            return 1;
		case (unsigned char)kItemPressure:
			return 1;
		default: 
			return 0;            
	}
    return 0;
}




unsigned char Decoder::crcCheck(unsigned char* header,int header_length, unsigned char* data, int data_length)
{
    unsigned char crc = 0;
    while (header_length-- > 0)
    {
        crc = crc + header[header_length];
    }
    while (data_length-- > 0)
    {
        crc = crc + data[data_length];
    }
    return crc;
}











