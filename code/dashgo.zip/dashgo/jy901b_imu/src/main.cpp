#include <jy901b_imu/jy901b_ros.h>

int main(int argc, char** argv)
{
    ros::init(argc, argv, "jy901b_imu_node");
    ros::NodeHandle nh("jy901b_imu");
	
	std::string port;
	nh.param<std::string>("/jy901b_imu_node/port", port, "/dev/ttyUSB0");
	port = "serial://" + port;
    jy901b_imu::Jy901b_ros imu_device(nh, port);
    imu_device.mainloop();
    return 0;
}
