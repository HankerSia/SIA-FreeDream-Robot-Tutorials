#ifndef DECODER_H
#define DECODER_H

//communication status
enum status{
    kStatus_Idle,
    KStatus_DataType,
    kStatus_Data,
    KStatus_Check
};

//data type
enum ItemID{  
    kItemAccRaw = 0x51,   
    kItemGyoRaw = 0x52,      
    kItemAtdE = 0x53,
    kItemMagRaw = 0x54,   
    kItemPressure = 0x56, 
};

//jy901b_imu data package type definition
struct SAcc
{
	float a[3];
	float T;
};
struct SGyro
{
	float w[3];
	float T;
};
struct SAngle
{
	float Angle[3];
	float T;
};
struct SMag
{
	float h[3];
	float T;
};


class Decoder
{
public:
    Decoder()
    {
         receive_state_ = kStatus_Idle;//初始为空闲状态，等待接收数据
         MAX_PACKET_LEN = 200;         //数据包的最大长度为200
	 	 DataCounter = 0;
         DataLen = 8;
    }
    unsigned char byteAnalysisCall(const unsigned char rx_byte);

private:
    unsigned char receiveFiniteStates(const unsigned char rx_data);
    unsigned char packageAnalysis(void);
    unsigned char crcCheck(unsigned char* header,int header_length, unsigned char* data, int data_length);
    
    //used for communication
    short   MAX_PACKET_LEN;  //一个数据包的最大长度
    short   DataLen;         //数据包长度
    status  receive_state_;  //数据接收状态
    int     DataCounter;     //数据索引
    unsigned char    header[2];       //表头数据
    unsigned char    DataBuf[8];    //存储接收的数据
    unsigned char  CRCReceived;
    unsigned char   CRCCalculated;

public:     
     //存储jy901b_imu数据
     struct SAcc 		stcAcc;
     struct SGyro 		stcGyro;
     struct SAngle 	stcAngle;
     struct SMag 		stcMag;  
};


#endif  // #ifndef DECODER_H

