#ifndef JY901B_ROS_
#define JY901B_ROS_

#include <vector>
#include <realtime_tools/realtime_publisher.h>
#include <cmath>
// for ros headers
#include <ros/ros.h>
#include <ros/callback_queue.h>
#include <geometry_msgs/Quaternion.h>
#include <sensor_msgs/Imu.h>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>
#include <std_srvs/Empty.h>
#include <string>
#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>


// for imu and transport
#include <jy901b_imu/transport.h>
#include <jy901b_imu/transport_serial.h>
#include <jy901b_imu/decoder.h>
#include <jy901b_imu/jy901b.h>

namespace jy901b_imu {


class Jy901b_ros {
public:
	//节点句柄，串口路径，配置文件路径
	Jy901b_ros(ros::NodeHandle &nh, std::string url);

	void mainloop();

private:
	//communication with embeded system
	Jy901b jy901b_;    
	ros::NodeHandle nh_;
	bool debug_mode;
	float yaw_correction;

	//imu data
	float roll, pitch, yaw;
	float base_yaw,filter_yaw;
	float current_yaw,last_yaw;
	float sum_yaw;
	float yaw_value_buffer[20];
	int   yaw_value_index;
	//控制指令更新，发布期望的速度指令
	inline void writeBufferUpdate(){}
  	//更新测量数据
	inline void readBufferUpdate()
	{
		//读取imu数据
		roll  = jy901b_.decoder_->stcAngle.Angle[0];
		pitch = jy901b_.decoder_->stcAngle.Angle[1];
		yaw   = jy901b_.decoder_->stcAngle.Angle[2];
		//std::cout << roll <<"\t" << pitch <<"\t"<< yaw << std::endl; 
	}
	
  	std::string tf_parent_frame_id;
  	std::string tf_frame_id;
  	std::string imu_frame_id;
  	double time_offset_in_seconds;

  	tf::Quaternion orientation;
  	tf::Quaternion zero_orientation;

  	ros::Publisher imu_pub;
  	ros::Publisher imu_angle_pub;
	double controller_freq_;  //控制频率


	//用于设置航向角零点，通过service的方式
	ros::ServiceServer service;
	bool zero_orientation_set;
	bool set_zero_orientation(std_srvs::Empty::Request&,std_srvs::Empty::Response&);

};

}


#endif
