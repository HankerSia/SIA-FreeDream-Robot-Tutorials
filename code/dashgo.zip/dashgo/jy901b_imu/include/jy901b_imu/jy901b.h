#ifndef JY901B_H_
#define JY901B_H_

#include <fstream>
#include <jy901b_imu/transport_serial.h>
#include <jy901b_imu/decoder.h>
#include <cstdlib>

namespace jy901b_imu {

class Jy901b{
public:
	//串口路径，配置文件路径
	Jy901b(std::string url);

	bool updateIMUData();

	inline boost::shared_ptr<boost::asio::io_service> getIOinstace()
	{
		return port_->getIOinstace();
	}

	inline bool initialize_ok () const
	{
		return initialize_ok_;
	}
	boost::shared_ptr<Decoder> decoder_;
private:
	boost::shared_ptr<Transport> port_;
	
	boost::shared_ptr<boost::asio::deadline_timer> timer_;

	//for reading config file
	std::fstream file_;
	bool initialize_ok_;
	//for updating data

	int time_out_;
	bool time_out_flag_;
	boost::mutex wait_mutex_;
	bool ack_ready_;
	void timeoutHandler(const boost::system::error_code &ec);
};

}


#endif /* JY901B_H_ */
